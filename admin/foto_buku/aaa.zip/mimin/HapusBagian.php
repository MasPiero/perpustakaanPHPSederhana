<?php 
include('../koneksi.php');
$kode_bagian = $_GET['kode_bagian'];
$query = mysqli_query($link,"delete from tbbagian where kode_bagian='$kode_bagian'") or die(mysqli_error());

 echo "<meta http-equiv='refresh' content='0; url=beranda.php?hal=Bagian'>";
?>