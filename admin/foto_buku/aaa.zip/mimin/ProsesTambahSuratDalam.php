<?php

include "../koneksi.php";
	
	$no_resi		= $_POST['no_resi'];
	$kode_kpp		= $_POST['kode_kpp'];
	$kode_bagian	= $_POST['kode_bagian'];
	$no_surat		= $_POST['no_surat'];
	$tgl_masuk		= $_POST['tgl_masuk'];
	$id_jenis_surat	= $_POST['id_jenis_surat'];
	$id_golongan	= $_POST['id_golongan'];
	$qty			= $_POST['qty'];
	$tujuan_nama	= $_POST['tujuan_nama'];
	$nama_penerima	= $_POST['nama_penerima'];
	$tujuan_jalan	= $_POST['tujuan_jalan'];
	$tgl_keluar		= $_POST['tgl_keluar'];
	$kode_kurir		= $_POST['kode_kurir'];

	


	$query =mysqli_query($link,"INSERT INTO tbsuratdalam (id,no_resi,kode_kpp,kode_bagian,no_surat,tgl_masuk,id_jenis_surat,id_golongan,qty,tujuan_nama,nama_penerima,alamat,tgl_keluar,kode_kurir,id_status) VALUES ('','$no_resi','$kode_kpp','$kode_bagian','$no_surat','$tgl_masuk','$id_jenis_surat','$id_golongan','$qty','$tujuan_nama','$nama_penerima','$tujuan_jalan','$tgl_keluar','$kode_kurir',7)");
	
	if($query){
		echo "<script>window.alert('Data Surat Jalan Berhasil Ditambah')</script>";
 		echo "<meta http-equiv='refresh' content='0; url=surat-dalam-kota'>";
	}
	




?>