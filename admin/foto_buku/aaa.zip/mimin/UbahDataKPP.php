<?php
include "../koneksi.php";
$kode_kpp = $_GET['kode_kpp'];
$query = mysqli_query($link,"SELECT * FROM tbkpp WHERE kode_kpp='$kode_kpp'");
while($data = mysqli_fetch_array($query)){
  ?>

 <div class="page-title">
          <div>
            <h1><i class="fa fa-map-o"></i> Ubah KPP</h1>
            <p>KPP</p>
          </div>
</div>

<div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="row">
                <div class="col-lg-8">
                  <div class="well bs-component">
                    <form action = "ProsesUbahKPP.php" class="form-horizontal" method="post" enctype="multipart/form-data">
                     
                        <legend>Ubah KPP</legend>
                        <div class="form-group" hidden>
                          <label class="col-lg-3 control-label" for="">Kode KPP</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "kode_kpp" id="" type="text" value = "<?php echo $data['kode_kpp'];  ?>" 
                          </div>
                       	 </div>
                        
                        </div>
                        <div class="form-group">
                          <label class="col-lg-3 control-label" for="">Nama KPP</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "nama_kpp" id="" type="text" value = "<?php echo $data['nama_kpp'];  ?>" 
                          </div>
                       	 </div>
                        </div>
                         <div class="form-group">
                          <label class="col-lg-3 control-label" for="">Username KPP</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "username" id="" type="text" value = "<?php echo $data['username'];  ?>" 
                          </div>
                        </div>
                         </div>
                        <div class="form-group">
                          <label class="col-lg-3 control-label" for="">Password KPP</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "password" id="" type="text" value = "<?php echo $data['password'];  ?>" 
                          </div>
                         </div>
                        </div>
                        <div class="form-group">
                          <div class="col-lg-8 col-lg-offset-3">
                         	 <button class="btn btn-primary" type="submit">Submit</button>
                             <button class="btn btn-default" type="reset">Cancel</button>
                            
                          </div>
                        
                    </div>
                  </form>
                 <?php

             }
             ?>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>