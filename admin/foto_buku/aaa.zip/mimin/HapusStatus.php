<?php 
include('../koneksi.php');
$id_status = $_GET['id_status'];
$query = mysqli_query($link,"delete from tbstatus where id_status='$id_status'") or die(mysql_error());

 echo "<meta http-equiv='refresh' content='0; url=beranda.php?hal=DataStatus'>";
?>