
<?php 
// menghubungkan dengan koneksi
include '../koneksi.php';
// menghubungkan dengan library excel reader
include "excel_reader2.php";
?>

<?php
// upload file xls
$target = basename($_FILES['import']['name']) ;
move_uploaded_file($_FILES['import']['tmp_name'], $target);

// beri permisi agar file xls dapat di baca
chmod($_FILES['import']['name'],0777);

// mengambil isi file xls
$data = new Spreadsheet_Excel_Reader($_FILES['import']['name'],false);
// menghitung jumlah baris data yang ada
$jumlah_baris = $data->rowcount($sheet_index=0);

// jumlah default data yang berhasil di import
$berhasil = 0;
for ($i=2; $i<=$jumlah_baris; $i++){

	// menangkap data dan memasukkan ke variabel sesuai dengan kolumnya masing-masing
	$no_resi     = $data->val($i, 1);
	$kode_kpp   = $data->val($i, 2);
	$kode_bagian  = $data->val($i, 3);
	$no_surat  = $data->val($i, 4);
	$tgl_masuk  = $data->val($i, 5);
	$id_jenis_surat  = $data->val($i, 6);
	$id_golongan  = $data->val($i, 7);
	$qty  = $data->val($i, 8);
	$tujuan_nama  = $data->val($i, 9);
	$nama_penerima  = $data->val($i, 10);
	$alamat  = $data->val($i, 11);
	$tgl_keluar  = $data->val($i, 12);
	$kode_kurir  = $data->val($i, 13);
	$id_status  = $data->val($i, 14);
	


	$cari = mysqli_num_rows(mysqli_query($link,"SELECT no_resi FROM tbsuratdalam WHERE no_resi = '$no_resi'"));

if (empty($no_resi)){
  $hasil = mysqli_query($link,"INSERT INTO tbgagal(id,no_resi,keterangan) VALUES('','$no_resi','Resi Kosong')");
 }
 elseif ($cari > 0){
  $hasil = mysqli_query($link,"INSERT INTO tbgagal(id,no-resi,keterangan) VALUES('','$no_resi','Duplikasi Nama')");
 }
 else{
  // setelah data dibaca, sisipkan ke dalam tabel tsukses
  $hasil = mysqli_query($link,"INSERT INTO tbsuratdalam (id,no_resi,kode_kpp,kode_bagian,no_surat,tgl_masuk,id_jenis_surat,id_golongan,qty,tujuan_nama,nama_penerima,alamat,tgl_keluar,kode_kurir,id_status) VALUES ('','$no_resi','$kode_kpp','$kode_bagian','$no_surat','$tgl_masuk','$id_jenis_surat','$id_golongan','$qty','$tujuan_nama','$nama_penerima','$alamat','$tgl_keluar','$kode_kurir','$id_status')");
 }

}

// hapus kembali file .xls yang di upload tadi
unlink($_FILES['import']['name']);



echo "<script>window.alert('Data Surat  Berhasil Diimport , Berhasil import')</script>";
 		echo "<meta http-equiv='refresh' content='0; url=surat-dalam-kota'>";
// alihkan halaman ke index.php

?>