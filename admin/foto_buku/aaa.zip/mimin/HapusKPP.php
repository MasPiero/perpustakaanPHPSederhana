<?php 
include('../koneksi.php');
$kode_kpp = $_GET['kode_kpp'];
$query = mysqli_query($link,"delete from tbkpp where kode_kpp='$kode_kpp'") or die(mysql_error());

 echo "<meta http-equiv='refresh' content='0; url=beranda.php?hal=DataKPP'>";
?>