<?php
include "../koneksi.php";
$kode_bagian = $_GET['kode_bagian'];
$query = mysqli_query($link,"SELECT * FROM tbbagian WHERE kode_bagian='$kode_bagian'");
while($data = mysqli_fetch_array($query)){
  ?>

 <div class="page-title">
          <div>
            <h1><i class="fa fa-map-o"></i> Ubah Bagian / Seksdi</h1>
            <p>KPP</p>
          </div>
</div>

<div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="row">
                <div class="col-lg-8">
                  <div class="well bs-component">
                    <form action = "ProsesUbahBagian.php" class="form-horizontal" method="post" enctype="multipart/form-data">
                     
                        <legend>Edit Kategori</legend>
                        <div class="form-group" hidden>
                          <label class="col-lg-3 control-label" for="">Kode Bagian</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "kode_bagian" id="" type="text" value = "<?php echo $data['kode_bagian'];  ?>" 
                          </div>
                       	 </div>
                        
                        </div>
                        <div class="form-group">
                          <label class="col-lg-3 control-label" for="">Nama Bagian</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "nama_bagian" id="" type="text" value = "<?php echo $data['nama_bagian'];  ?>" 
                          </div>
                       	 </div>
                        
                        </div>
                        <div class="form-group">
                          <div class="col-lg-8 col-lg-offset-3">
                         	 <button class="btn btn-primary" type="submit">Submit</button>
                             <button class="btn btn-default" type="reset">Cancel</button>
                            
                          </div>
                        
                    </div>
                  </form>
                 <?php

             }
             ?>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>