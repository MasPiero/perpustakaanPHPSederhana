<?php

include 'FungsiExport.php';
//koneksi ke database dan jalankan query
mysql_connect('localhost', 'root', '');
mysql_select_db('db_ksp');
$result = mysql_query("SELECT * FROM tbsuratluar LEFT JOIN tbkpp on tbsuratluar.kode_kpp = tbkpp.kode_kpp LEFT JOIN tbbagian on tbsuratluar.kode_bagian=tbbagian.kode_bagian LEFT JOIN tbstatus on tbsuratluar.id_status = tbstatus.id_status");
!$result?die(mysql_error()):'';
//pengaturan nama file
$namaFile = "SuratLuarKota.xls";
//pengaturan judul data
$judul = "Daftar Surat Luar Kota";
//baris berapa header tabel di tulis
$tablehead = 2;
//baris berapa data mulai di tulis
$tablebody = 3;
//no urut data
$nourut = 1;
//penulisan header
header("Pragma: public");
header("Expires: 0");
header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
header("Content-Type: application/force-download");
header("Content-Type: application/octet-stream");
header("Content-Type: application/download");
header("Content-Disposition: attachment;filename=".$namaFile."");
header("Content-Transfer-Encoding: binary ");
xlsBOF();
xlsWriteLabel(0,0,$judul);
$kolomhead = 0;
xlsWriteLabel($tablehead,$kolomhead++,"No");
xlsWriteLabel($tablehead,$kolomhead++,"No Resi");
xlsWriteLabel($tablehead,$kolomhead++,"No Surat");
xlsWriteLabel($tablehead,$kolomhead++,"Nama KPP");
xlsWriteLabel($tablehead,$kolomhead++,"Nama Bagian");
xlsWriteLabel($tablehead,$kolomhead++,"Tanggal Masuk");
xlsWriteLabel($tablehead,$kolomhead++,"Qty");
xlsWriteLabel($tablehead,$kolomhead++,"Harga");
xlsWriteLabel($tablehead,$kolomhead++,"Harga+3000");
xlsWriteLabel($tablehead,$kolomhead++,"Penerima");
xlsWriteLabel($tablehead,$kolomhead++,"Alamat");
xlsWriteLabel($tablehead,$kolomhead++,"Status");
while ($data = mysql_fetch_array($result))
{
$kolombody = 0;
//gunakan xlsWriteNumber untuk penulisan nomor dan xlsWriteLabel untuk penulisan string
xlsWriteNumber($tablebody,$kolombody++,$nourut);
xlsWriteLabel($tablebody,$kolombody++,$data['no_surat']);
xlsWriteLabel($tablebody,$kolombody++,$data['no_resi']);
xlsWriteLabel($tablebody,$kolombody++,$data['nama_kpp']);
xlsWriteLabel($tablebody,$kolombody++,$data['nama_bagian']);
xlsWriteLabel($tablebody,$kolombody++,$data['tgl_masuk']);
xlsWriteNumber($tablebody,$kolombody++,$data['qty']);
xlsWriteNumber($tablebody,$kolombody++,$data['harga']);
xlsWriteNumber($tablebody,$kolombody++,$data['harga']+3000);
xlsWriteLabel($tablebody,$kolombody++,$data['tujuan_nama']);
xlsWriteLabel($tablebody,$kolombody++,$data['tujuan_jalan']);
xlsWriteLabel($tablebody,$kolombody++,$data['nama_status']);
$tablebody++;
$nourut++;
}
xlsEOF();
exit();


?>