<div class="page-title">
          <div>
            <h1><i class="fa fa-user"></i> Tambah Booking</h1>
            <p>PO Lubuk Basung</p>
          </div>
          <div>
            <ul class="breadcrumb">
              <li><i class="fa fa-user fa-lg"></i></li>
              <li><a href="#">Data Booking Tiket</a></li>
            </ul>
          </div>
</div>

<form method="POST" action="validasi.php">
 <div class="col-md-6">
            <div class="card">
              <div class="card-title-w-btn">
                <h3 class="title">Pilih Tanggal Berangkat</h3>
               
              </div>
              <div class="card-body">
                
                <input class="form-control" id="demoDate" name="tanggal" type="text" placeholder="Select Date">
                <br>
                <button class="btn btn-primary" type="submit">Submit</button>
              
              </div>
            </div>
          </div>




