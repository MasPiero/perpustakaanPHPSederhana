<?php
include "../koneksi.php";
	
	$id_jenis_surat	= $_POST['id_jenis_surat'];
	$nama_jenis_surat	= $_POST['nama_jenis_surat'];
	
	




$edit = mysqli_query($link,"UPDATE tbjenissurat SET nama_jenis_surat='$nama_jenis_surat' WHERE id_jenis_surat='$id_jenis_surat' ");

echo "<script>alert('Data Telah Berhasil diubah!!!');
window.location='jenis-surat'</script>";


?>