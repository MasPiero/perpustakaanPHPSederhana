<?php

include "../koneksi.php";
	
	$nama_status		= $_POST['nama_status'];
	


	$query =mysqli_query($link,"INSERT INTO  tbstatus (id_status,nama_status) VALUES ('','$nama_status')");
	
	if($query){
		echo "<script>window.alert('Data Jenis Status Berhasil Ditambah')</script>";
 		echo "<meta http-equiv='refresh' content='0; url=status'>";
	}
	




?>