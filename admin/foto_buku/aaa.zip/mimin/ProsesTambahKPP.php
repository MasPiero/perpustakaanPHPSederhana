<?php

include "../koneksi.php";
	
	$nama_kpp		= $_POST['nama_kpp'];
	$username		= $_POST['username'];
	$password		= $_POST['password'];
	


	$query =mysqli_query($link,"INSERT INTO tbkpp (kode_kpp,nama_kpp,username,password) VALUES ('','$nama_kpp','$username','$password')");
	
	if($query){
		echo "<script>window.alert('Data KPP Berhasil Ditambah')</script>";
 		echo "<meta http-equiv='refresh' content='0; url=data-kpp'>";
	}
	




?>