<?php
include "../koneksi.php";
	
	$id_suratluar	= $_POST['id_suratluar'];
	
	$id_status	= $_POST['id_status'];
		




$edit = mysqli_query($link,"UPDATE tbsuratluar SET id_status = '$id_status' WHERE id_suratluar='$id_suratluar' ");

echo "<script>alert('Data Telah Berhasil diupdate!!!');
window.location='surat-luar-kota'</script>";


?>