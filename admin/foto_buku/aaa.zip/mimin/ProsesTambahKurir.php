<?php

include "../koneksi.php";
	
	$nama_kurir		= $_POST['nama_kurir'];
	


	$query =mysqli_query($link,"INSERT INTO tbkurir (kode_kurir,nama_kurir) VALUES ('','$nama_kurir')");
	
	if($query){
		echo "<script>window.alert('Data Kurir Berhasil Ditambah')</script>";
 		echo "<meta http-equiv='refresh' content='0; url=kurir'>";
	}
	




?>