<div class="page-title">
          <div>
            <h1><i class="fa fa-user"></i> Import Data Surat Luar Kota</h1>
            <p>PT. Wime Media Universal</p>
          </div>
          <div>
            <ul class="breadcrumb">
              <li><i class="fa fa-user fa-lg"></i></li>
              <li><a href="#">Import Data Surat Luar Kota</a></li>
            </ul>
          </div>
</div>

<div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="row">
                <div class="col-lg-8">
                  <div class="well bs-component">
                    <form action = "ProsesImportSuratLuar.php" class="form-horizontal" method="post" enctype="multipart/form-data">
                     
                        <legend>Import Data Surat Luar Kota</legend>
                        
                         <div class="form-group">
                          <label class="col-lg-3 control-label" for="inputEmail">Unggah File</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "import" id="import" type="file" placeholder="">
                          </div>
                         </div>
                         
                       
                        
                        </div>
                        <div class="form-group">
                          <div class="col-lg-8 col-lg-offset-3">
                           <button class="btn btn-primary" type="submit">Simpan</button>
                             <button class="btn btn-default" type="reset">Batal</button>
                            
                          </div>
                        
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>