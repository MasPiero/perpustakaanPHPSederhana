<?php 
include('../koneksi.php');
$id_jenis_surat = $_GET['id_jenis_surat'];
$query = mysqli_query($link,"delete from tbjenissurat where id_jenis_surat='$id_jenis_surat'") or die(mysql_error());

 echo "<meta http-equiv='refresh' content='0; url=beranda.php?hal=JenisSurat'>";
?>