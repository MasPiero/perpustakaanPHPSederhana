<?php 
include('../koneksi.php');
$kode_kurir = $_GET['kode_kurir'];
$query = mysqli_query($link,"delete from tbkurir where kode_kurir='$kode_kurir'") or die(mysql_error());

 echo "<meta http-equiv='refresh' content='0; url=beranda.php?hal=Kurir'>";
?>