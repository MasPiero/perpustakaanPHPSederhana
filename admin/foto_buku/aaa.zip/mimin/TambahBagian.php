<div class="page-title">
          <div>
            <h1><i class="fa fa-user"></i> Tambah Bagian</h1>
            <p>PT. Wime Media Universal</p>
          </div>
          <div>
            <ul class="breadcrumb">
              <li><i class="fa fa-user fa-lg"></i></li>
              <li><a href="#">Tambah Bagian</a></li>
            </ul>
          </div>
</div>

<div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="row">
                <div class="col-lg-8">
                  <div class="well bs-component">
                    <form action = "ProsesTambahBagian.php" class="form-horizontal" method="post" enctype="multipart/form-data">
                     
                        <legend>Tambah Data Bagian</legend>
                        <div class="form-group">
                          <label class="col-lg-3 control-label" for="">Kode Bagian</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "kode_bagian" id="" type="text" placeholder="Kode Bagian">
                          </div>
                         </div>
                         <div class="form-group">
                          <label class="col-lg-3 control-label" for="inputEmail">Nama Bagian</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "nama_bagian" id="nama_bagian" type="text" placeholder="Nama Bagian">
                          </div>
                         </div>
                       
                        
                        </div>
                        <div class="form-group">
                          <div class="col-lg-8 col-lg-offset-3">
                           <button class="btn btn-primary" type="submit">Simpan</button>
                             <button class="btn btn-default" type="reset">Batal</button>
                            
                          </div>
                        
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>