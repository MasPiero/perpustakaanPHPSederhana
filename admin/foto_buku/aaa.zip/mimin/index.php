<?php
header('location:beranda.php?hal=Home');
?>