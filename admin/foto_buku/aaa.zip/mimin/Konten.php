<?php
if  ($_GET['hal']=='beranda')
	{include "beranda.php";}

	
else if  ($_GET['hal']=='Home')
	{include "Home.php";}


else if  ($_GET['hal']=='Bagian')
	{include "Bagian.php";}

else if  ($_GET['hal']=='Kurir')
	{include "Kurir.php";}
else if  ($_GET['hal']=='SuratDalamKota')
	{include "SuratDalamKota.php";}
else if  ($_GET['hal']=='SuratLuarKota')
	{include "SuratLuarKota.php";}
else if  ($_GET['hal']=='TambahBagian')
	{include "TambahBagian.php";}
else if  ($_GET['hal']=='TambahKurir')
	{include "TambahKurir.php";}
else if  ($_GET['hal']=='DataKPP')
	{include "DataKPP.php";}
else if  ($_GET['hal']=='TambahKPP')
	{include "TambahKPP.php";}
else if  ($_GET['hal']=='JenisSurat')
	{include "JenisSurat.php";}
else if  ($_GET['hal']=='TambahJenisSurat')
	{include "TambahJenisSurat.php";}
else if  ($_GET['hal']=='DataStatus')
	{include "DataStatus.php";}
else if  ($_GET['hal']=='TambahStatus')
	{include "TambahStatus.php";}
else if  ($_GET['hal']=='TambahSuratDalam')
	{include "TambahSuratDalam.php";}
else if  ($_GET['hal']=='TambahSuratLuar')
	{include "TambahSuratLuar.php";}
else if  ($_GET['hal']=='UbahDataBagian')
	{include "UbahDataBagian.php";}
else if  ($_GET['hal']=='UbahDataKurir')
	{include "UbahDataKurir.php";}
else if  ($_GET['hal']=='UbahDataKPP')
	{include "UbahDataKPP.php";}
else if  ($_GET['hal']=='UbahDataJenisSurat')
	{include "UbahDataJenisSurat.php";}
else if  ($_GET['hal']=='UbahDataStatus')
	{include "UbahDataStatus.php";}
else if  ($_GET['hal']=='DetailSuratDalam')
	{include "DetailSuratDalam.php";}
else if  ($_GET['hal']=='DetailSuratLuar')
	{include "DetailSuratLuar.php";}
else if  ($_GET['hal']=='UbahSuratDalamKota')
	{include "UbahSuratDalamKota.php";}
else if  ($_GET['hal']=='UbahSuratLuarKota')
	{include "UbahSuratLuarKota.php";}
else if  ($_GET['hal']=='LaporanSuratDalam')
	{include "LaporanSuratDalam.php";}
else if  ($_GET['hal']=='LaporanSuratLuar')
	{include "LaporanSuratLuar.php";}
else if  ($_GET['hal']=='UbahStatus')
	{include "UbahStatus.php";}
else if  ($_GET['hal']=='UbahStatusLuar')
	{include "UbahStatusLuar.php";}
else if  ($_GET['hal']=='UbahDataKPP')
	{include "UbahDataKPP.php";}
else if  ($_GET['hal']=='ImportDataLuar')
	{include "ImportDataLuar.php";}
else if  ($_GET['hal']=='ImportDataDalam')
	{include "ImportDataDalam.php";}

?>