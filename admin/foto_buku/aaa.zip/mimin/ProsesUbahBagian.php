<?php
include "../koneksi.php";
	
	$kode_bagian	= $_POST['kode_bagian'];
	$nama_bagian	= $_POST['nama_bagian'];
	
	




$edit = mysqli_query($link,"UPDATE tbbagian SET nama_bagian='$nama_bagian' WHERE kode_bagian='$kode_bagian' ");

echo "<script>alert('Data Telah Berhasil diubah!!!');
window.location='bagian'</script>";


?>