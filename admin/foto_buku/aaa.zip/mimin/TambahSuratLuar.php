<div class="page-title">
          <div>
            <h1><i class="fa fa-envelope"></i> Tambah Surat Luar Kota</h1>
            <p>KPP</p>
          </div>
          <div>
            <ul class="breadcrumb">
              <li><i class="fa fa-envelope fa-lg"></i></li>
              <li><a href="#">Tambah Surat Luar Kota</a></li>
            </ul>
          </div>
</div>

<div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="row">
                <div class="col-lg-8">
                  <div class="well bs-component">
                    <form action = "ProsesTambahSuratLuar.php" class="form-horizontal" method="post" enctype="multipart/form-data">
                     
                        <legend>Tambah Data Surat Luar Kota</legend>
                        <div class="form-group">
                          <label class="col-lg-3 control-label" for="">No Resi</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "no_resi" id="" type="text" placeholder="No Resi" required="">
                          </div>
                         </div>
                         <div class="form-group">
                          <label class="col-sm-3 control-label" for="">KPP</label>
                           <div class="col-lg-9">
                           <?php
                              include "../koneksi.php";

                            echo "<select class='form-control' name='kode_kpp'>";
                            $tampil = mysqli_query($link,"SELECT * FROM tbkpp");
                           
                            while($w=mysqli_fetch_array($tampil))
                                  {
                          echo "<option value=$w[kode_kpp] selected>$w[nama_kpp]</option>";        
                            }
                             echo "</select>";
                            ?>
                        </div>
                           </div>
                           <div class="form-group">
                          <label class="col-sm-3 control-label" for="">Bagian</label>
                           <div class="col-lg-9">
                           <?php
                              include "../koneksi.php";

                            echo "<select class='form-control' name='kode_bagian'>";
                            $tampil = mysqli_query($link,"SELECT * FROM tbbagian");
                           
                            while($w=mysqli_fetch_array($tampil))
                                  {
                          echo "<option value=$w[kode_bagian] selected>$w[nama_bagian]</option>";        
                            }
                             echo "</select>";
                            ?>
                        </div>
                           </div>
                        <div class="form-group">
                          <label class="col-lg-3 control-label" for="">No Surat</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "no_surat"  type="text" placeholder="No Surat" required="">
                           </div>
                           </div>
                           <div class="form-group">
                          <label class="col-lg-3 control-label" for="inputEmail">Tanggal Surat Masuk</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "tgl_masuk" type="date" >
                          </div>
                         </div>
                        
                           <div class="form-group">
                          <label class="col-sm-3 control-label" for="">Golongan</label>
                           <div class="col-lg-9">
                           <?php
                              include "../koneksi.php";

                            echo "<select class='form-control' name='id_golongan'>";
                            $tampil = mysqli_query($link,"SELECT * FROM tbgolongan");
                           
                            while($w=mysqli_fetch_array($tampil))
                                  {
                          echo "<option value=$w[id_golongan] selected>$w[nama_golongan]</option>";        
                            }
                             echo "</select>";
                            ?>
                        </div>
                           </div>
                            <div class="form-group">
                          <label class="col-sm-3 control-label" for="">Qty</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "qty" id="" type="number" placeholder="Qty" required="">
                           </div>
                           </div>

                            <div class="form-group">
                          <label class="col-sm-3 control-label" for="">Harga</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "harga" id="" type="number" placeholder="Harga" required="">
                           </div>
                           </div>
                           
                            <div class="form-group">
                          <label class="col-lg-3 control-label" for="">Tujuan Nama</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "tujuan_nama" id="tujuan_nama" type="text" placeholder="Tujuan nama" required="">
                           </div>
                           </div>

                             <div class="form-group">
                          <label class="col-lg-3 control-label" for="">Penerima</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "penerima" id="penerima" type="text" placeholder="Penerima" required="">
                           </div>
                           </div>
                           
                           <div class="form-group">
                          <label class="col-lg-3 control-label" for="textArea">Tujuan Jalan</label>
                          <div class="col-lg-9">
                            <textarea class="form-control" name ="tujuan_jalan" id="tujuan_jalan" rows="3" placeholder="Tujuan jalan"></textarea>
                          </div>
                        </div>
                        
                        <div class="form-group">
                          <div class="col-lg-8 col-lg-offset-3">
                           <button class="btn btn-primary" type="submit">Submit</button>
                             <button class="btn btn-default" type="reset">Cancel</button>
                            
                          </div>
                        
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>