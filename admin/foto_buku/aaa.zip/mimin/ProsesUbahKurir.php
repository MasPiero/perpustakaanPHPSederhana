<?php
include "../koneksi.php";
	
	$kode_kurir	= $_POST['kode_kurir'];
	$nama_kurir	= $_POST['nama_kurir'];
	
	




$edit = mysqli_query($link,"UPDATE tbkurir SET nama_kurir='$nama_kurir' WHERE kode_kurir='$kode_kurir' ");

echo "<script>alert('Data Telah Berhasil diubah!!!');
window.location='kurir'</script>";


?>