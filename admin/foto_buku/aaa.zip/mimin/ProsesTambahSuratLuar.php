<?php

include "../koneksi.php";
	
	$no_resi		= $_POST['no_resi'];
	$kode_kpp		= $_POST['kode_kpp'];
	$kode_bagian	= $_POST['kode_bagian'];
	$no_surat		= $_POST['no_surat'];
	$tgl_masuk		= $_POST['tgl_masuk'];
	$id_golongan	= $_POST['id_golongan'];
	$qty			= $_POST['qty'];
	$harga			= $_POST['harga'];
	$tujuan_nama	= $_POST['tujuan_nama'];
	$penerima	= $_POST['penerima'];
	$tujuan_jalan	= $_POST['tujuan_jalan'];

	


	$query =mysqli_query($link,"INSERT INTO tbsuratluar (id_suratluar,no_resi,kode_kpp,kode_bagian,no_surat,tgl_masuk,id_golongan,qty,harga,tujuan_nama,penerima,tujuan_jalan,id_status) VALUES ('','$no_resi','$kode_kpp','$kode_bagian','$no_surat','$tgl_masuk','$id_golongan','$qty','$harga','$tujuan_nama','$penerima','$tujuan_jalan','7')");
	
	if($query){
		echo "<script>window.alert('Data Surat Jalan Berhasil Ditambah')</script>";
 		echo "<meta http-equiv='refresh' content='0; url=surat-luar-kota'>";
	}
	




?>