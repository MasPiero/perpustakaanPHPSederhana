<?php
include "../koneksi.php";
	
	$id	= $_POST['id'];
	$tgl_keluar	= $_POST['tgl_keluar'];
	$id_status	= $_POST['id_status'];
	




$edit = mysqli_query($link,"UPDATE tbsuratdalam SET tgl_keluar='$tgl_keluar' , id_status = '$id_status' WHERE id='$id' ");

echo "<script>alert('Data Telah Berhasil diupdate!!!');
window.location='surat-dalam-kota'</script>";


?>