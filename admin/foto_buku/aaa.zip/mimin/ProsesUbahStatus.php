<?php
include "../koneksi.php";
	
	$id	= $_POST['id_status'];
	$nama_status	= $_POST['nama_status'];
	
	




$edit = mysqli_query($link,"UPDATE tbstatus SET nama_status='$nama_status' WHERE id_status='$id' ");

echo "<script>alert('Data Telah Berhasil diubah!!!');
window.location='status'</script>";


?>