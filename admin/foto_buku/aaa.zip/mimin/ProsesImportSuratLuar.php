
<?php 
// menghubungkan dengan koneksi
include '../koneksi.php';
// menghubungkan dengan library excel reader
include "excel_reader2.php";
?>

<?php
// upload file xls
$target = basename($_FILES['import']['name']) ;
move_uploaded_file($_FILES['import']['tmp_name'], $target);

// beri permisi agar file xls dapat di baca
chmod($_FILES['import']['name'],0777);

// mengambil isi file xls
$data = new Spreadsheet_Excel_Reader($_FILES['import']['name'],false);
// menghitung jumlah baris data yang ada
$jumlah_baris = $data->rowcount($sheet_index=0);

// jumlah default data yang berhasil di import
$berhasil = 0;
for ($i=2; $i<=$jumlah_baris; $i++){

	// menangkap data dan memasukkan ke variabel sesuai dengan kolumnya masing-masing
	$no_resi     = $data->val($i, 1);
	$kode_kpp   = $data->val($i, 2);
	$kode_bagian  = $data->val($i, 3);
	$no_surat  = $data->val($i, 4);
	$tgl_masuk  = $data->val($i, 5);
	$id_golongan  = $data->val($i, 6);
	$qty  = $data->val($i, 7);
	$harga  = $data->val($i, 8);
	$tujuan_nama  = $data->val($i, 9);
	$penerima  = $data->val($i, 10);
	$tujuan_jalan  = $data->val($i, 11);
	$id_status  = $data->val($i, 12);


	$cari = mysqli_num_rows(mysqli_query($link,"SELECT no_resi FROM tbsuratluar WHERE no_resi = '$no_resi'"));

if (empty($no_resi)){
  $hasil = mysqli_query($link,"INSERT INTO tbgagal(id,no_resi,keterangan) VALUES('','$no_resi','Resi Kosong')");
 }
 elseif ($cari > 0){
  $hasil = mysqli_query($link,"INSERT INTO tbgagal(id,no-resi,keterangan) VALUES('','$no_resi','Duplikasi Nama')");
 }
 else{
  // setelah data dibaca, sisipkan ke dalam tabel tsukses
  $hasil = mysqli_query($link,"INSERT INTO tbsuratluar (id_suratluar,no_resi,kode_kpp,kode_bagian,no_surat,tgl_masuk,id_golongan,qty,harga,tujuan_nama,penerima,tujuan_jalan,id_status) VALUES ('','$no_resi','$kode_kpp','$kode_bagian','$no_surat','$tgl_masuk','$id_golongan','$qty','$harga','$tujuan_nama','$penerima','$tujuan_jalan','$id_status')");
 }

}

// hapus kembali file .xls yang di upload tadi
unlink($_FILES['import']['name']);



echo "<script>window.alert('Data Surat Jalan Berhasil Diimport , Berhasil import')</script>";
 		echo "<meta http-equiv='refresh' content='0; url=surat-luar-kota'>";
// alihkan halaman ke index.php

?>