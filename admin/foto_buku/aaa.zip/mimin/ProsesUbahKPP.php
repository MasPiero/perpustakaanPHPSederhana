<?php
include "../koneksi.php";
	
	$kode_kpp	= $_POST['kode_kpp'];
	$nama_kpp	= $_POST['nama_kpp'];
	$username	= $_POST['username'];
	$password	= $_POST['password'];
	
	




$edit = mysqli_query($link,"UPDATE tbkpp SET nama_kpp='$nama_kpp' , password='$password', password='$password'WHERE kode_kpp='$kode_kpp' ");

echo "<script>alert('Data Telah Berhasil diubah!!!');
window.location='data-kpp'</script>";


?>