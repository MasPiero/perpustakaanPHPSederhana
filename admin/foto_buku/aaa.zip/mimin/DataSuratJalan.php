<?php
include "../Fungsi.php";

?>
<div class="page-title">
          <div>
            <h1><i class="fa fa-user"></i> Data Surat Jalan</h1>
            <p>PO Lubuk Basung</p>
          </div>
          <div>
            <ul class="breadcrumb">
              <li><i class="fa fa-user fa-lg"></i></li>
              <li><a href="#">Data Surat Jalan</a></li>
            </ul>
          </div>
</div>

<div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-body">
                <?php
                             $tampil=mysqli_query ($link,"SELECT * FROM tbsuratjalan");
                              
                             ?>
                <table class="table table-hover table-bordered" id="sampleTable">
                <div class="text-left">
                     
                 </div>
                 <br><br>
                  <thead>
                    <tr>
                       
                      <th>No Surat Jalan</th>
                      <th>Tanggal Berangkat</th>
                      <th>Tujuan</th>
                      <th>Nama Supir</th>
                      <th>No Pool</th>
                       
                       <th>Aksi</th>
                     
                      
                      
                      
                    </tr>
                  </thead>
                  <tbody>
                    <?php while($data=mysqli_fetch_array($tampil))
                      { 
                        
                        ?>
                        <tr>
                         
                          <td><?php echo $data['id_surat']; ?></td>
                          <td><?php echo  tgl_indo($data['tanggal_berangkat']); ?></td>
                          <td><?php echo $data['tujuan']; ?></td>
                          <td><?php echo $data['nama_supir']; ?></td>
                          
                           <td><?php echo $data['no_pol']; ?></td>
                            
                          <td><a class="btn btn-primary" target="_blank"  href="CetakSJ.php?id_surat=<?php echo $data['id_surat']  ?>">Cetak SJ</a>
                          <a class="btn btn-primary" target="_blank"  href="CetakBooking.php?id_booking=<?php echo $data['id_booking']  ?>">Detail</a>
                          </td>
                                               
                          
                          
                         </tr>
                       
                                                                                        
                     <?php   
                  }
                  ?>
                  
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Javascripts-->
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugins/pace.min.js"></script>
    
    <!-- Data table plugin-->
    <script type="text/javascript" src="js/plugins/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="js/plugins/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">$('#sampleTable').DataTable();</script>