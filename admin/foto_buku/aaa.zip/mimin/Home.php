
<?php
include"../koneksi.php";
session_start();
if(empty($_SESSION['id'])){

  echo "<script>window.alert('Login Terlebih Dahulu')</script>";
  echo "<meta http-equiv='refresh' content='0; url=../index.html'>";
}
else{

?>

<div class="page-title">
		<div>
            <h1><i class="fa fa-home"></i> Beranda Admin</h1>
            <p>PT. Wime Media Universal</p>
          </div>
          <div>
            <ul class="breadcrumb">
              <li><i class="fa fa-home fa-lg"></i></li>
              <li><a href="#">Beranda</a></li>
            </ul>
 			</div>
 </div>

 <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-body">



              		<div class="row">
          <div class="col-md-6">
            <div class="widget-small info"><i class="icon fa fa-users fa-4x"></i>
              <div class="info">
                <h4>Total Cabang KPP</h4>
                <p><h5><b><?php
                include "koneksi.php";
                                  
                  $query = mysqli_query($link,"SELECT nama_kpp FROM tbkpp ");
                  $count = mysqli_num_rows($query);
                  echo "$count";?> Cabang
              </b></h5></p>
              </div>
            </div>
          </div>
           <div class="col-md-6">
            <div class="widget-small info"><i class="icon fa fa-bicycle fa-4x"></i>
              <div class="info">
                <h4>Total Kurir</h4>
                <p><h5><b><?php
                                  
                  $query = mysqli_query($link,"SELECT nama_kurir FROM tbkurir ");
                  $count = mysqli_num_rows($query);
                  echo "$count";?>
              </b></h5></p>
              </div>
            </div>
          </div>


          <div class="col-md-6">
            <div class="widget-small primary"><i class="icon fa fa-envelope fa-4x"></i>
              <div class="info">
                <h4>Total Surat Dalam Kota</h4>
                <p><h5><b><?php
                                  
                  $query = mysqli_query($link,"SELECT kode_kpp FROM tbsuratdalam ");
                  $count = mysqli_num_rows($query);
                  echo "$count";?>
              </b></h5></p>
              </div>
            </div>
          </div>
           <div class="col-md-6">
            <div class="widget-small primary"><i class="icon fa fa-truck fa-4x"></i>
              <div class="info">
                <h4>Total Surat Luar Kota</h4>
                <p><h5><b><?php
                                  
                  $query = mysqli_query($link,"SELECT kode_kpp FROM tbsuratluar ");
                  $count = mysqli_num_rows($query);
                  echo "$count";?>
              </b></h5></p>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="widget-small warning"><i class="icon fa fa-angle-double-left fa-4x"></i>
              <div class="info">
                <h4>Surat Terkirim</h4>
                <p><h5><b><?php
                                  
                  $query = mysqli_query($link,"SELECT id_status FROM tbsuratdalam where id_status='1' ");
                  $count = mysqli_num_rows($query);
                  echo "$count";?>
              </b></h5></p>
              </div>
            </div>
          </div>

 <div class="col-md-3">
            <div class="widget-small warning"><i class="icon fa fa-angle-double-right fa-4x"></i>
              <div class="info">
                <h4>Surat On Proses</h4>
                <p><h5><b><?php
                                  
                  $query = mysqli_query($link,"SELECT id_status FROM tbsuratdalam where id_status!='1'");
                  $count = mysqli_num_rows($query);
                  echo "$count";?>
              </b></h5></p>
              </div>
            </div>
          </div>

           <div class="col-md-3">
            <div class="widget-small warning"><i class="icon fa fa-angle-double-left fa-4x"></i>
              <div class="info">
                <h4>Surat Terkirim</h4>
                <p><h5><b><?php
                                  
                  $query = mysqli_query($link,"SELECT id_status FROM tbsuratluar where id_status='7' ");
                  $count = mysqli_num_rows($query);
                  echo "$count";?>
              </b></h5></p>
              </div>
            </div>
          </div>

 <div class="col-md-3">
            <div class="widget-small warning"><i class="icon fa fa-angle-double-right fa-4x"></i>
              <div class="info">
                <h4>Surat On Proses</h4>
                <p><h5><b><?php
                                  
                  $query = mysqli_query($link,"SELECT id_status FROM tbsuratluar where id_status !='7' ");
                  $count = mysqli_num_rows($query);
                  echo "$count";?>
              </b></h5></p>
              </div>
            </div>
          </div>
              </div>
             </div>
            </div>
  </div>

<?php
}
?>