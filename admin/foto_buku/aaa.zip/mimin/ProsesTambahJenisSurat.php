<?php

include "../koneksi.php";
	
	$nama_jenis_surat		= $_POST['nama_jenis_surat'];
	


	$query =mysqli_query($link,"INSERT INTO tbjenissurat (id_jenis_surat,nama_jenis_surat) VALUES ('','$nama_jenis_surat')");
	
	if($query){
		echo "<script>window.alert('Data Jenis Surat Berhasil Ditambah')</script>";
 		echo "<meta http-equiv='refresh' content='0; url=jenis-surat'>";
	}
	




?>