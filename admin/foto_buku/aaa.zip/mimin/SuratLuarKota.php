<?php
include "../Fungsi.php";

?>
<div class="page-title">
          <div>
            <h1><i class="fa fa-user"></i> Master Surat Luar Kota</h1>
            <p>PT. Wime Media Universal</p>
          </div>
          <div>
            <ul class="breadcrumb">
              <li><i class="fa fa-user fa-lg"></i></li>
              <li><a href="#">Master Surat Luar Kota</a></li>
            </ul>
          </div>
</div>

<div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-body">
                <?php
                             $tampil=mysqli_query ($link,"SELECT * FROM tbsuratluar LEFT JOIN tbkpp on tbsuratluar.kode_kpp = tbkpp.kode_kpp LEFT JOIN tbbagian on tbsuratluar.kode_bagian=tbbagian.kode_bagian LEFT JOIN tbstatus on tbsuratluar.id_status = tbstatus.id_status order by id_suratluar DESC");
                            $no=0;  
                             ?>
                <table class="table table-hover table-bordered" id="sampleTable">
               <div class="text-left">
                     <a href="tambah-surat-luar" class="btn btn-sm btn-primary">Tambah Surat <i class="fa fa-arrow-circle-right"></i></a>
                 </div>
                 <br><br>
                  <thead>
                    <tr>
                       
                      <th>No</th>
                      <th>No. Resi</th>
                       <th>KPP</th>
                       <th>Bagian</th>
                        <th>No Surat</th>
                         <th>Tgl. Surat Masuk</th>
                         
                            <th>Qty</th>
                             <th>Nama Penerima</th>
                             <th>Status</th>
                             
                                <th>Aksi</th>

                     
                      
                      
                      
                    </tr>
                  </thead>
                  <tbody>
                    <?php while($data=mysqli_fetch_array($tampil))
                      { 
                        $no++;
                        ?>
                        <tr>
                         
                          <td><?php echo $no;; ?></td>
                         
                          <td><?php echo $data['no_resi']; ?></td>
                           <td><?php echo $data['nama_kpp']; ?></td>
                            <td><?php echo $data['nama_bagian']; ?></td>
                             <td><?php echo $data['no_surat']; ?></td>
                              <td><?php echo tgl_indo($data['tgl_masuk']); ?></td>
                             
                              <td><?php echo $data['qty']; ?></td>
                              <td><?php echo $data['penerima']; ?></td>
                               <td><?php 
                                 if ($data['nama_status'] ==  "Terkirim")
                                  {echo "<span class='label label-primary'>  $data[nama_status]</span> <a class='btn btn-primary' data-toggle='tooltip' title='Ubah Status' href='beranda.php?hal=UbahStatusLuar&id_suratluar=$data[id_suratluar]'> <i class='fa fa-arrow-up'></i></a> ";}
                                 elseif ($data['nama_status'] ==  "Proses Input")
                                  {echo "<span class='label label-info'>  $data[nama_status]</span> <a class='btn btn-info' data-toggle='tooltip' title='Ubah Status' href='beranda.php?hal=UbahStatusLuar&id_suratluar=$data[id_suratluar]'> <i class='fa fa-arrow-up'></i></a> ";}
                                  else
                                  { echo "<span class='label label-warning'> $data[nama_status] </span><a class='btn btn-warning' data-toggle='tooltip' title='Ubah Status' href='beranda.php?hal=UbahStatusLuar&id_suratluar=$data[id_suratluar]'><i class='fa fa-arrow-up'></i></a>";}
                               ?></td>
                             
                                                     
                           <td><a class="btn btn-info"   href="beranda.php?hal=DetailSuratLuar&id_suratluar=<?php echo $data['id_suratluar']  ?>"> <i class="fa fa-arrow-left"></i></a> <a class="btn btn-primary" data-toggle="tooltip" title="Ubah"  href="beranda.php?hal=UbahSuratLuarKota&id_suratluar=<?php echo $data['id_suratluar'] ?>"> <i class="fa fa-edit"></i></a>
                          <a class="btn btn-danger"  onclick="return confirm('Yakin Hapus?')" href="HapusSuratLuar.php?id_suratluar=<?php echo $data['id_suratluar']  ?>"><i class="fa fa-trash"></i></a>
                           <a class="btn btn-default" target="_blank" data-toggle="tooltip" title="Cetak" href="CetakSuratLuar.php?id_suratluar=<?php echo $data['id_suratluar']  ?>"><i class="fa fa-print"></i></a>
                          </td>
                                               
                          
                          
                         </tr>
                       
                                                                                        
                     <?php   
                  }
                  ?>
                  
                  </tbody>
                </table>
              </div>
                <a class="btn btn-primary" href="import-data-luar"> <i class="fa fa-upload"> Import Data</i></a>
                  <a class="btn btn-primary" href="ExportDataLuar.php"> <i class="fa fa-download"> Export Data</i></a>
            </div>
          </div>
       

    <!-- Javascripts-->
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugins/pace.min.js"></script>
    
    <!-- Data table plugin-->
    <script type="text/javascript" src="js/plugins/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="js/plugins/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">$('#sampleTable').DataTable();</script>