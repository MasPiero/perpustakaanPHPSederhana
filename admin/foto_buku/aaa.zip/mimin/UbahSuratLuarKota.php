<?php
include "../koneksi.php";
$id_suratluar = $_GET['id_suratluar'];
$query = mysqli_query($link,"SELECT * FROM tbsuratluar LEFT JOIN tbkpp on tbsuratluar.kode_kpp = tbkpp.kode_kpp LEFT JOIN tbbagian on tbsuratluar.kode_bagian=tbbagian.kode_bagian LEFT JOIN tbstatus on tbsuratluar.id_status = tbstatus.id_status  where tbsuratluar.id_suratluar = '$id_suratluar'");

while($data = mysqli_fetch_array($query)){
  ?>

 <div class="page-title">
          <div>
            <h1><i class="fa fa-map-o"></i> Ubah Surat Luar Kota</h1>
            <p>KPP</p>
          </div>
</div>

<div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="row">
                <div class="col-lg-8">
                  <div class="well bs-component">
                    <form action = "" class="form-horizontal" method="post" enctype="multipart/form-data">
                     
                        <legend>Ubah Surat Luar Kota </legend>
                        <div class="form-group" hidden>
                          <label class="col-lg-3 control-label" for="">id</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "kode_bagian" id="" type="text" value = "<?php echo $data['id_suratluar'];  ?>"
                          </div>
                       	 </div>
                        
                        </div>
                        <div class="form-group">
                          <label class="col-lg-3 control-label" for="">No Resi</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "no-resi" id="" type="text" value = "<?php echo $data['no_resi'];   ?>" 
                          </div>
                       	 </div>
                        
                        </div>

                         <div class="form-group">
                          <label class="col-sm-3 control-label" for="">KPP</label>
                           <div class="col-lg-9">
                           <?php
                              include "../koneksi.php";

                            echo "<select class='form-control' name='kode_kpp'>";
                            $tampil = mysqli_query($link,"SELECT * FROM tbkpp");
                           
                            while($w=mysqli_fetch_array($tampil))
                              {

                                if($data['kode_kpp']== $w['kode_kpp']){
                                 echo "<option value=$w[kode_kpp] selected>$w[nama_kpp]</option>";        
                                  }
                                  else{
                                  echo "<option value=$w[kode_kpp]>$w[nama_kpp]</option>"; 
                                  }
                            }

                             echo "</select>";
                            

                            ?>
                        </div>
                           </div>
                             <div class="form-group">
                          <label class="col-sm-3 control-label" for="">Bagian/Seksi</label>
                           <div class="col-lg-9">
                           <?php
                              include "../koneksi.php";

                            echo "<select class='form-control' name='kode_kpp'>";
                            $tampil = mysqli_query($link,"SELECT * FROM tbbagian");
                           
                            while($w=mysqli_fetch_array($tampil))
                              {

                                if($data['kode_bagian']== $w['kode_bagian']){
                                 echo "<option value=$w[kode_bagian] selected>$w[nama_bagian]</option>";        
                                  }
                                  else{
                                  echo "<option value=$w[kode_bagian]>$w[nama_bagian]</option>"; 
                                  }
                            }

                             echo "</select>";
                            

                            ?>
                        </div>
                           </div>

                          <div class="form-group">
                          <label class="col-lg-3 control-label" for="">No Surat</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "nama_bagian" id=""  type="text" value = "<?php echo $data['no_surat'];   ?>" 
                          </div>
                         </div>
                        
                        </div>
                          <div class="form-group">
                          <label class="col-lg-3 control-label" for="">Tanggal Masuk</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "tgl_masuk" id=""  type="date" value = "<?php echo $data['tgl_masuk'];   ?>" 
                          </div>
                         </div>
                        
                        </div>
                          
                          <div class="form-group">
                          <label class="col-sm-3 control-label" for="">Golongan</label>
                           <div class="col-lg-9">
                           <?php
                              include "../koneksi.php";

                            echo "<select class='form-control' name='kode_kpp'>";
                            $tampil = mysqli_query($link,"SELECT * FROM tbgolongan");
                           
                            while($w=mysqli_fetch_array($tampil))
                              {

                                if($data['nama_golongan']== $w['nama_golongan']){
                                 echo "<option value=$w[nama_golongan] selected>$w[nama_golongan]</option>";        
                                  }
                                  else{
                                  echo "<option value=$w[nama_golongan]>$w[nama_golongan]</option>"; 
                                  }
                            }

                             echo "</select>";
                            

                            ?>
                        </div>
                           </div>
                          <div class="form-group">
                          <label class="col-lg-3 control-label" for="">Qty</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "nama_bagian" id=""  type="text" value = "<?php echo $data['qty'];   ?>" 
                          </div>
                         </div>

                          </div>
                          <div class="form-group">
                          <label class="col-lg-3 control-label" for="">Tujuan Nama</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "tujuan_nama" id=""  type="text" value = "<?php echo $data['tujuan_nama'];   ?>" 
                          </div>
                         </div>
                        
                        </div>
                          <div class="form-group">
                          <label class="col-lg-3 control-label" for="">Penerima</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "tujuan_nama" id=""  type="text" value = "<?php echo $data['nama_penerima'];   ?>" 
                          </div>
                         </div>
                        
                        </div>
                          <div class="form-group">
                          <label class="col-lg-3 control-label" for="">Alamat</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "nama_bagian" id=""  type="text" value = "<?php echo $data['tujuan_jalan'];   ?>" 
                          </div>
                         </div>
                        
                        </div>
                          <div class="form-group">
                          <label class="col-lg-3 control-label" for="">Tanggal Surat Keluar</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "nama_bagian" id=""  type="date" value = "<?php echo $data['tgl_keluar'];   ?>" 
                          </div>
                         </div>
                        
                        </div>
                          
                        <div class="form-group">
                          <div class="col-lg-8 col-lg-offset-3">
                         	 
                             <a class="btn btn-primary" href="beranda.php?hal=SuratLuarKota"> <i class="fa fa-arrow-left">Kembali</i></a>
                            
                          </div>
                        
                    </div>

                  </form>
                 <?php

             }
             ?>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>