<?php
include "../koneksi.php";
$id = $_GET['id_status'];
$query = mysqli_query($link,"SELECT * FROM tbstatus WHERE id_status='$id'");
while($data = mysqli_fetch_array($query)){
  ?>

 <div class="page-title">
          <div>
            <h1><i class="fa fa-map-o"></i> Ubah Kurir</h1>
            <p>KPP</p>
          </div>
</div>

<div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="row">
                <div class="col-lg-8">
                  <div class="well bs-component">
                    <form action = "ProsesUbahStatus.php" class="form-horizontal" method="post" enctype="multipart/form-data">
                     
                        <legend>Edit Status</legend>
                        <div class="form-group" hidden>
                          <label class="col-lg-3 control-label" for="">id</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "id_status" id="" type="text" value = "<?php echo $data['id_status'];  ?>" 
                          </div>
                       	 </div>
                        
                        </div>
                        <div class="form-group">
                          <label class="col-lg-3 control-label" for="">Nama Status</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "nama_status" id="" type="text" value = "<?php echo $data['nama_status'];  ?>" 
                          </div>
                       	 </div>
                        
                        </div>
                        <div class="form-group">
                          <div class="col-lg-8 col-lg-offset-3">
                         	 <button class="btn btn-primary" type="submit">Ubah</button>
                             <button class="btn btn-default" type="reset">Cancel</button>
                            
                          </div>
                        
                    </div>
                  </form>
                 <?php

             }
             ?>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>