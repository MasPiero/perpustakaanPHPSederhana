


            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title"><i class="fa fa-print"></i> Cetak laporan Surat Luar Kota </h3>
              </div>
              <div class="panel-body">
                 <div class="table-responsive">
                  
    <form action="ProsesLaporanSuratLuar.php" method="post">
    <table class="table table-condensed">
    
      <div class="form-group">

              <div class="col-md-6">
              <label>Tanggal Awal</label>
              <input type="date" class="form-control  " name="tanggal_awal"  required>
              
            
            
              <label>Tanggal Akhir</label>
             
              <input type="date" class="form-control" name="tanggal_akhir"  required>
                <br>
                <input type="submit" value="Cetak Laporan" name="SimpanData" target="_blank" class="btn btn-sm btn-primary"/>&nbsp;<a href="?hal=depan" class="btn btn-sm btn-primary">Kembali</a>
            </div>
              
              
      
        
                </div>
              </div> 
            </div>
          </div>
        </div><!-- /.row --> 
      </div><!-- /#page-wrapper -->

    </div><!-- /#wrapper -->

    <!-- JavaScript -->
    <script src="js/jquery-1.10.2.js"></script>
    <script src="js/bootstrap.js"></script>

    <!-- Page Specific Plugins -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="http://cdn.oesmith.co.uk/morris-0.4.3.min.js"></script>
    <script src="js/morris/chart-data-morris.js"></script>
    <script src="js/tablesorter/jquery.tablesorter.js"></script>
    <script src="js/tablesorter/tables.js"></script>

 