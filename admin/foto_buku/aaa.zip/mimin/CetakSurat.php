
<head>
	<title>PT. Wime Media Unversal</title>
</head>

<?php
include "../koneksi.php";
include "FungsiTanggal.php";
$id = $_GET['id'];
$data = mysqli_fetch_array(mysqli_query($link,"SELECT * FROM tbsuratdalam LEFT JOIN tbkpp on tbsuratdalam.kode_kpp=tbkpp.kode_kpp where id = '$id'"));
error_reporting(0);
?>

<h2><CENTER><u> PT. WIME MEDIA UNIVERSAL</u> <br>
Telp : 021-7823215</CENTER></h2>





<table rules="all" border="1" width="100%">
<tr>
		<td width="15%">Tanggal</td>
		<td width="100%">: <?php echo tgl_indo($data['tgl_masuk']) ?></td>
</tr>
<tr>
		<td width="15%">No Surat</td>
		<td width="100%">: <?php echo $data['no_surat'] ?></td>
</tr>

<tr>
		<td width="15%">No Resi</td>
		<td width="100%">: <?php echo $data['no_resi'] ?></td>
</tr>
<tr>
		<td width="15%">Tujuan Nama</td>
		<td width="100%">: <?php echo $data['nama_penerima'] ?></td>
</tr>
<tr>
		<td width="15%">Tujuan Alamat</td>
		<td width="100%">: <?php echo $data['alamat'] ?></td>
</tr>
<tr>
		<td width="15%">Dari</td>
		<td width="100%">: <?php echo $data['nama_kpp'] ?></td>
</tr>




</table>

<br>

Penerima
<br>
<br>
<br>
<br>
<br>
<br>




