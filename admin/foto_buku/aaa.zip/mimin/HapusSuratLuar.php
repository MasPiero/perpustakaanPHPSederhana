<?php 
include('../koneksi.php');
$id = $_GET['id_suratluar'];
$query = mysqli_query($link,"delete from tbsuratluar where id_suratluar='$id'") or die(mysql_error());

 echo "<meta http-equiv='refresh' content='0; url=beranda.php?hal=SuratLuarKota'>";
?>