<?php

include "../koneksi.php";
	$kode_bagian			= $_POST['kode_bagian'];
	$nama_bagian		= $_POST['nama_bagian'];
	


	$query =mysqli_query($link,"INSERT INTO tbbagian (kode_bagian,nama_bagian) VALUES ('$kode_bagian','$nama_bagian')");
	
	if($query){
		echo "<script>window.alert('Data Bagian Berhasil Ditambah')</script>";
 		echo "<meta http-equiv='refresh' content='0; url=bagian'>";
	}
	




?>