<?php
include "../koneksi.php";
include "FungsiTanggal.php";
$hari_ini  = date("Y-m-d");

$g = 'LBJ';
$b = 'JKT';
$c = array('','I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII');
$d = date('y');
$tahun = date('Y');
$tgl = date('m');
$cek = mysql_fetch_array(mysql_query("SELECT id_surat FROM tbsuratjalan WHERE date_format(tanggal_berangkat,'%m')='$tgl' and date_format(tanggal_berangkat,'%Y')='$tahun' ORDER BY id_surat+0 DESC LIMIT 1"));
$ex = explode('/', $cek['id_surat']);
 
if ($cek['id_surat']){ $a = $ex[0]+1; }

else{ $a = '1'; }
 

$id_surat = $a.'/'.$b.'/'.$g.'/'.$c[date('n')].'/'.$d;


?>



<div class="page-title">
          <div>
            <h1><i class="fa fa-user"></i>Data Penumpang</h1>
            <p>PO Lubuk Basung</p>
          </div>
          <div>
            <ul class="breadcrumb">
              <li><i class="fa fa-user fa-lg"></i></li>
              <li><a href="#">Data Penumpang </a></li>
            </ul>
          </div>
</div>




<!--  Sisi Kiri  -->
<form method="post" action="ProsesSuratJalan.php">
           <div class="col-md-6">
            <div class="card">
              <div class="card-body">

                 <h2><center><i class="fa fa-user"></i> Data Penumpang</h2></center>
                  <br>
                <br>
                 <?php
                             $tampil=mysql_query ("SELECT * FROM tbbooking LEFT JOIN tbdestinasi on tbbooking.id_destinasi=tbdestinasi.id_destinasi where status ='Lunas' and jadwal_berangkat = '$hari_ini'");
                              $nomor = 0;
                             ?>
                <table class="table table-hover table-bordered" id="sampleTable">
                
                  <thead>
                    <tr>
                       <th>No Booking</th>
                      <th>Nama</th>
                      <th>Tujuan </th>
                      <th>Jml bangku</th>
                      <th>Aksi</th>
                     
                      
                      
                      
                    </tr>
                  </thead>
                  <tbody>
                    <?php while($data=mysql_fetch_array($tampil))
                      { 
                      
                        ?>
                        <tr>
                          <td><?php echo $data['id_booking']; ?></td>
                          <td><?php echo $data['nama']; ?></td>
                          <td><?php echo $data['jalur_destinasi']; ?></td>
                          <td><?php echo $data['jumlah_tiket']; ?></td>
                          <td><a class="btn btn-primary" href="beranda.php?hal=TukarBangku&id_booking=<?php echo $data['id_booking'] ?>">Lihat</a></td>
                                               
                          
                          
                         </tr>
                       
                                                                                        
                     <?php   
                  }
                  ?>
                  
                  </tbody>
                </table>
                
              </div>
            </div>
          </div>





 <div class="row">
          <div class="col-md-6">
            <div class="card">
              <div class="card-body">

                 <h2><center><i class="fa fa-edit"></i> Input Surat Jalan</h2></center>

                 <form method="post" action="Update.php">


    <div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Id Surat</label>
                          <div class="col-lg-10">
                            <input class="form-control" name="id_surat" type="text" placeholder="Nama Pemesan" value="<?php echo $id_surat ?>" readonly>
                          </div>
                        </div>
                <div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Tujuan Akhir</label>
                          <div class="col-lg-10">
                            <input class="form-control" name="tujuan" type="text" placeholder="Tujuan" required>
                          </div>
                        </div>
                 <div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Nama Supir</label>
                          <div class="col-lg-10">
                            <input class="form-control" name="nama_supir" type="text" placeholder="Nama Supir" required="">
                          </div>
                        </div>

                  <div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">No Kendaraan</label>
                          <div class="col-lg-10">
                            <input class="form-control" name="no_pol" type="text" placeholder="No kendaraan" required="" >
                          </div>
                        </div>

                  <div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Trip Ke-</label>
                          <div class="col-lg-10">
                            <input class="form-control" name="trip" type="text" placeholder="No trip" required="" >
                          </div>
                        </div>
                  <div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Pool + Adm</label>
                          <div class="col-lg-10">
                            <input class="form-control" name="pool" type="text" placeholder="No trip" required="" >
                          </div>
                        </div>

                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Mel Terminal</label>
                          <div class="col-lg-10">
                            <input class="form-control" name="mel" type="text" placeholder="No trip" required="" >
                          </div>
                        </div>
                         <div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Burs</label>
                          <div class="col-lg-10">
                            <input class="form-control" name="burs" type="text" placeholder="No trip" required="" >
                          </div>
                        </div>

                        <div class="form-group">
                          <div class="col-lg-10 col-lg-offset-2"> 
                            <button class="btn btn-primary" type="submit">Simpan</button>
                            <button class="btn btn-default" type="reset">Batal</button>
                          </div>
                        </div>
                      </form>



              </div>
            </div>
          </div>