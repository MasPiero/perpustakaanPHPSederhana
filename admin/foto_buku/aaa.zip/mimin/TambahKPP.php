<div class="page-title">
          <div>
            <h1><i class="fa fa-user"></i> Tambah KPP</h1>
            <p>PT. Wime Media Universal</p>
          </div>
          <div>
            <ul class="breadcrumb">
              <li><i class="fa fa-user fa-lg"></i></li>
              <li><a href="#">Tambah KPP</a></li>
            </ul>
          </div>
</div>

<div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="row">
                <div class="col-lg-8">
                  <div class="well bs-component">
                    <form action = "ProsesTambahKPP.php" class="form-horizontal" method="post" enctype="multipart/form-data">
                     
                        <legend>Tambah Data KPP</legend>
                        
                         <div class="form-group">
                          <label class="col-lg-3 control-label" for="inputEmail">Nama KPP</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "nama_kpp" id="nama_kpp" type="text" placeholder="Nama KPP">
                          </div>
                         </div>
                          <div class="form-group">
                          <label class="col-lg-3 control-label" for="inputEmail">Username KPP</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "username" id="" type="text" placeholder="username">
                          </div>

                         </div>
                          <div class="form-group">
                          <label class="col-lg-3 control-label" for="inputEmail">Password KPP</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "password" id="" type="text" placeholder="Password">
                          </div>
                         </div>
                       
                        
                        </div>
                        <div class="form-group">
                          <div class="col-lg-8 col-lg-offset-3">
                           <button class="btn btn-primary" type="submit">Simpan</button>
                             <button class="btn btn-default" type="reset">Batal</button>
                            
                          </div>
                        
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>