<?php
include "../Fungsi.php";

?>
<div class="page-title">
          <div>
            <h1><i class="fa fa-user"></i> Data Seksi/Bagian</h1>
            <p>PT. Wime Media Universal</p>
          </div>
          <div>
            <ul class="breadcrumb">
              <li><i class="fa fa-user fa-lg"></i></li>
              <li><a href="#">Data Seksi/Bagian</a></li>
            </ul>
          </div>
</div>

<div class="row">
          <div class="col-md-8">
            <div class="card">
              <div class="card-body">
                <?php
                             $tampil=mysqli_query ($link,"SELECT * FROM tbbagian");
                              
                             ?>
                <table class="table table-hover table-bordered" id="sampleTable">
               <div class="text-left">
                     <a href="tambah-bagian" class="btn btn-sm btn-primary">Tambah Bagian <i class="fa fa-arrow-circle-right"></i></a>
                 </div>
                 <br><br>
                  <thead>
                    <tr>
                       
                      <th>Kode</th>
                      <th>Nama Bagian</th>
                      
                       
                       <th>Aksi</th>
                     
                      
                      
                      
                    </tr>
                  </thead>
                  <tbody>
                    <?php while($data=mysqli_fetch_array($tampil))
                      { 
                        
                        ?>
                        <tr>
                         
                          <td><?php echo $data['kode_bagian']; ?></td>
                         
                          <td><?php echo $data['nama_bagian']; ?></td>
                         
                            
                          <td><a class="btn btn-primary"  href="beranda.php?hal=UbahDataBagian&kode_bagian=<?php echo $data['kode_bagian']  ?>">Ubah</a>
                          <a class="btn btn-danger" onclick="return confirm('Yakin Hapus?')"  href="HapusBagian.php?kode_bagian=<?php echo $data['kode_bagian']  ?>">Hapus</a>
                          </td>
                                               
                          
                          
                         </tr>
                       
                                                                                        
                     <?php   
                  }
                  ?>
                  
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Javascripts-->
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugins/pace.min.js"></script>
    
    <!-- Data table plugin-->
    <script type="text/javascript" src="js/plugins/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="js/plugins/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">$('#sampleTable').DataTable();</script>