<?php
include "../koneksi.php";
$kode_kurir = $_GET['kode_kurir'];
$query = mysqli_query($link,"SELECT * FROM tbkurir WHERE kode_kurir='$kode_kurir'");
while($data = mysqli_fetch_array($query)){
  ?>

 <div class="page-title">
          <div>
            <h1><i class="fa fa-map-o"></i> Ubah Kurir</h1>
            <p>KPP</p>
          </div>
</div>

<div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="row">
                <div class="col-lg-8">
                  <div class="well bs-component">
                    <form action = "ProsesUbahKurir.php" class="form-horizontal" method="post" enctype="multipart/form-data">
                     
                        <legend>Edit Kategori</legend>
                        <div class="form-group" hidden>
                          <label class="col-lg-3 control-label" for="">Kode Kurir</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "kode_kurir" id="" type="text" value = "<?php echo $data['kode_kurir'];  ?>" 
                          </div>
                       	 </div>
                        
                        </div>
                        <div class="form-group">
                          <label class="col-lg-3 control-label" for="">Nama Kurir</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "nama_kurir" id="" type="text" value = "<?php echo $data['nama_kurir'];  ?>" 
                          </div>
                       	 </div>
                        
                        </div>
                        <div class="form-group">
                          <div class="col-lg-8 col-lg-offset-3">
                         	 <button class="btn btn-primary" type="submit">Submit</button>
                             <button class="btn btn-default" type="reset">Cancel</button>
                            
                          </div>
                        
                    </div>
                  </form>
                 <?php

             }
             ?>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>