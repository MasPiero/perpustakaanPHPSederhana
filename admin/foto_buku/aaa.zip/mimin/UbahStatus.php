<?php
include "../koneksi.php";
$id = $_GET['id'];
$query = mysqli_query($link,"SELECT * FROM tbsuratdalam LEFT JOIN tbkpp on tbsuratdalam.kode_kpp = tbkpp.kode_kpp LEFT JOIN tbbagian on tbsuratdalam.kode_bagian=tbbagian.kode_bagian LEFT JOIN tbkurir on tbsuratdalam.kode_kurir=tbkurir.kode_kurir where tbsuratdalam.id = '$id'");

while($data = mysqli_fetch_array($query)){
  ?>

 <div class="page-title">
          <div>
            <h1><i class="fa fa-map-o"></i> Ubah Surat Dalam Kota</h1>
            <p>KPP</p>
          </div>
</div>

<div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="row">
                <div class="col-lg-8">
                  <div class="well bs-component">
                    <form action = "ProsesUpdateStatus.php" class="form-horizontal" method="post" enctype="multipart/form-data">
                     
                        <legend>Ubah Surat Dalam Kota </legend>
                        <div class="form-group" hidden>
                          <label class="col-lg-3 control-label" for="">id</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "id" id="" type="text" value = "<?php echo $data['id'];  ?>"
                          </div>
                       	 </div>
                        
                        </div>
                        <div class="form-group">
                          <label class="col-lg-3 control-label" for="">No Resi</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "nama_bagian"  readonly id="" type="text" value = "<?php echo $data['no_resi'];   ?>" 
                          </div>
                       	 </div>
                        
                        </div>

                         <div class="form-group">
                          <label class="col-sm-3 control-label"  readonly  for="">KPP</label>
                           <div class="col-lg-9">
                           <?php
                              include "../koneksi.php";

                            echo "<select class='form-control'   readonly  name='kode_kpp'>";
                            $tampil = mysqli_query($link,"SELECT * FROM tbkpp");
                           
                            while($w=mysqli_fetch_array($tampil))
                              {

                                if($data['kode_kpp']== $w['kode_kpp']){
                                 echo "<option value=$w[kode_kpp] selected>$w[nama_kpp]</option>";        
                                  }
                                  else{
                                  echo "<option value=$w[kode_kpp]>$w[nama_kpp]</option>"; 
                                  }
                            }

                             echo "</select>";
                            

                            ?>
                        </div>
                           </div>
                             <div class="form-group">
                          <label class="col-sm-3 control-label"   for="">Bagian/Seksi</label>
                           <div class="col-lg-9">
                           <?php
                              include "../koneksi.php";

                            echo "<select class='form-control' readonly name='kode_kpp'>";
                            $tampil = mysqli_query($link,"SELECT * FROM tbbagian");
                           
                            while($w=mysqli_fetch_array($tampil))
                              {

                                if($data['kode_bagian']== $w['kode_bagian']){
                                 echo "<option value=$w[kode_bagian] selected>$w[nama_bagian]</option>";        
                                  }
                                  else{
                                  echo "<option value=$w[kode_bagian]>$w[nama_bagian]</option>"; 
                                  }
                            }

                             echo "</select>";
                            

                            ?>
                        </div>
                           </div>

                          <div class="form-group">
                          <label class="col-lg-3 control-label" for="">No Surat</label>
                          <div class="col-lg-9">
                            <input class="form-control" readonly name = "nama_bagian" id=""  type="text" value = "<?php echo $data['no_surat'];   ?>" 
                          </div>
                         </div>
                        
                        </div>
                          <div class="form-group">
                          <label class="col-lg-3 control-label" for="">Tanggal Masuk</label>
                          <div class="col-lg-9">
                            <input class="form-control" readonly name = "nama_bagian" id=""  type="date" value = "<?php echo $data['tgl_masuk'];   ?>" 
                          </div>
                         </div>
                        
                        </div>
                          <div class="form-group">
                          <label class="col-sm-3 control-label" for="">Jenis Surat</label>
                           <div class="col-lg-9">
                           <?php
                              include "../koneksi.php";

                            echo "<select class='form-control' readonly name='kode_npwp'>";
                            $tampil = mysqli_query($link,"SELECT * FROM tbjenissurat");
                           
                            while($w=mysqli_fetch_array($tampil))
                              {

                                if($data['id_jenis_surat']== $w['id_jenis_surat']){
                                 echo "<option value=$w[id_jenis_surat] selected>$w[nama_jenis_surat]</option>";        
                                  }
                                  else{
                                  echo "<option value=$w[id_jenis_surat]>$w[nama_jenis_surat]</option>"; 
                                  }
                            }

                             echo "</select>";
                            

                            ?>
                        </div>
                           </div>
                          <div class="form-group">
                          <label class="col-sm-3 control-label" for="">Golongan</label>
                           <div class="col-lg-9">
                           <?php
                              include "../koneksi.php";

                            echo "<select class='form-control' readonly name='id_golongan'>";
                            $tampil = mysqli_query($link,"SELECT * FROM tbgolongan");
                           
                            while($w=mysqli_fetch_array($tampil))
                              {

                                if($data['nama_golongan']== $w['nama_golongan']){
                                 echo "<option value=$w[nama_golongan] selected>$w[nama_golongan]</option>";        
                                  }
                                  else{
                                  echo "<option value=$w[nama_golongan]>$w[nama_golongan]</option>"; 
                                  }
                            }

                             echo "</select>";
                            

                            ?>
                        </div>
                           </div>
                          <div class="form-group">
                          <label class="col-lg-3 control-label" for="">Qty</label>
                          <div class="col-lg-9">
                            <input class="form-control" readonly name = "nama_bagian" id=""  type="text" value = "<?php echo $data['qty'];   ?>" 
                          </div>
                         </div>
                        
                        </div>
                          <div class="form-group">
                          <label class="col-lg-3 control-label" for="">Penerima</label>
                          <div class="col-lg-9">
                            <input class="form-control" readonly name = "nama_bagian" id=""  type="text" value = "<?php echo $data['nama_penerima'];   ?>" 
                          </div>
                         </div>
                        
                        </div>
                          <div class="form-group">
                          <label class="col-lg-3 control-label" for="">Alamat</label>
                          <div class="col-lg-9">
                            <input class="form-control" readonly name = "nama_bagian" id=""  type="text" value = "<?php echo $data['alamat'];   ?>" 
                          </div>
                         </div>
                        
                        </div>
                          <div class="form-group">
                          <label class="col-lg-3 control-label"  for="">Tanggal Surat Keluar</label>
                          <div class="col-lg-9">
                            <input class="form-control"  name = "tgl_keluar" id=""  type="date" value = "<?php echo $data['tgl_keluar'];   ?>" 
                          </div>
                         </div>
                        
                        </div>
                           <div class="form-group">
                          <label class="col-sm-3 control-label" for="">Kurir</label>
                           <div class="col-lg-9">
                           <?php
                              include "../koneksi.php";

                            echo "<select class='form-control' name='kode_kurir'>";
                            $tampil = mysqli_query($link,"SELECT * FROM tbkurir");
                           
                            while($w=mysqli_fetch_array($tampil))
                              {

                                if($data['kode_kurir']== $w['kode_kurir']){
                                 echo "<option value=$w[kode_kurir] selected>$w[nama_kurir]</option>";        
                                  }
                                  else{
                                  echo "<option value=$w[kode_kurir]>$w[nama_kurir]</option>"; 
                                  }
                            }

                             echo "</select>";
                            

                            ?>
                        </div>
                           </div>
                           <div class="form-group">
                          <label class="col-sm-3 control-label" for="">Status</label>
                           <div class="col-lg-9">
                           <?php
                              include "../koneksi.php";

                            echo "<select class='form-control' name='id_status'>";
                            $tampil = mysqli_query($link,"SELECT * FROM tbstatus");
                           
                            while($w=mysqli_fetch_array($tampil))
                              {

                                if($data['id_status']== $w['id_status']){
                                 echo "<option value=$w[id_status] selected>$w[nama_status]</option>";        
                                  }
                                  else{
                                  echo "<option value=$w[id_status]>$w[nama_status]</option>"; 
                                  }
                            }

                             echo "</select>";
                            

                            ?>
                        </div>
                           </div>
                        <div class="form-group">
                          <div class="col-lg-8 col-lg-offset-3">
                         	 <button class="btn btn-primary" type="submit">Update</button>
                             <a class="btn btn-primary" href="beranda.php?hal=SuratDalamKota"> <i class="fa fa-arrow-left">Kembali</i></a>
                            
                          </div>
                        
                    </div>

                  </form>
                 <?php

             }
             ?>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>