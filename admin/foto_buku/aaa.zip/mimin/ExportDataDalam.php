<?php

include 'FungsiExport.php';
//koneksi ke database dan jalankan query
mysql_connect('localhost', 'root', '');
mysql_select_db('db_ksp');
$result = mysql_query("SELECT * FROM tbsuratdalam Left Join tbkpp on tbsuratdalam.kpp = tbkpp.kode_kpp left join tbbagian on tbsuratdalam.kode_bagian = tbbagian.kode_bagian left join tbnpwp on tbsuratdalam.npwp = tbnpwp.id_npwp left join tbgolongan on tbsuratdalam.golongan = tbgolongan.id_golongan left join tbstatus on tbsuratdalam.id_status = tbstatus.id_status left join tbkurir on tbsuratdalam.kode_kurir = tbkurir.kode_kurir");
!$result?die(mysql_error()):'';
//pengaturan nama file
$namaFile = "DataSuratDalam.xls";
//pengaturan judul data
$judul = "Daftar Surat Dalam Kota";
//baris berapa header tabel di tulis
$tablehead = 2;
//baris berapa data mulai di tulis
$tablebody = 3;
//no urut data
$nourut = 1;
//penulisan header
header("Pragma: public");
header("Expires: 0");
header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
header("Content-Type: application/force-download");
header("Content-Type: application/octet-stream");
header("Content-Type: application/download");
header("Content-Disposition: attachment;filename=".$namaFile."");
header("Content-Transfer-Encoding: binary ");
xlsBOF();
xlsWriteLabel(0,0,$judul);
$kolomhead = 0;
xlsWriteLabel($tablehead,$kolomhead++,"No");
xlsWriteLabel($tablehead,$kolomhead++,"No Resi");
xlsWriteLabel($tablehead,$kolomhead++,"No Surat");
xlsWriteLabel($tablehead,$kolomhead++,"Nama KPP");
xlsWriteLabel($tablehead,$kolomhead++,"Nama Bagian");
xlsWriteLabel($tablehead,$kolomhead++,"Tanggal Masuk");
xlsWriteLabel($tablehead,$kolomhead++,"Jenis Surat");
xlsWriteLabel($tablehead,$kolomhead++,"Golongan");
xlsWriteLabel($tablehead,$kolomhead++,"Qty");
xlsWriteLabel($tablehead,$kolomhead++,"Penerima");
xlsWriteLabel($tablehead,$kolomhead++,"Alamat");
xlsWriteLabel($tablehead,$kolomhead++,"Tgl Keluar");
xlsWriteLabel($tablehead,$kolomhead++,"Nama kurir");
xlsWriteLabel($tablehead,$kolomhead++,"Status");
while ($data = mysql_fetch_array($result))
{
$kolombody = 0;
//gunakan xlsWriteNumber untuk penulisan nomor dan xlsWriteLabel untuk penulisan string
xlsWriteNumber($tablebody,$kolombody++,$nourut);
xlsWriteLabel($tablebody,$kolombody++,$data['no_surat']);
xlsWriteLabel($tablebody,$kolombody++,$data['no_resi']);
xlsWriteLabel($tablebody,$kolombody++,$data['nama_kpp']);
xlsWriteLabel($tablebody,$kolombody++,$data['nama_bagian']);
xlsWriteLabel($tablebody,$kolombody++,$data['tgl_masuk']);
xlsWriteLabel($tablebody,$kolombody++,$data['nama_npwp']);
xlsWriteLabel($tablebody,$kolombody++,$data['nama_golongan']);
xlsWriteNumber($tablebody,$kolombody++,$data['qty']);
xlsWriteLabel($tablebody,$kolombody++,$data['nama_penerima']);
xlsWriteLabel($tablebody,$kolombody++,$data['alamat']);
xlsWriteLabel($tablebody,$kolombody++,$data['tgl_keluar']);
xlsWriteLabel($tablebody,$kolombody++,$data['nama_kurir']);
xlsWriteLabel($tablebody,$kolombody++,$data['nama_status']);
$tablebody++;
$nourut++;
}
xlsEOF();
exit();


?>