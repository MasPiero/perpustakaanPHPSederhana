<div class="page-title">
          <div>
            <h1><i class="fa fa-user"></i> Tambah Status</h1>
            <p>Status xXx</p>
          </div>
          <div>
            <ul class="breadcrumb">
              <li><i class="fa fa-user fa-lg"></i></li>
              <li><a href="#">Tambah Status</a></li>
            </ul>
          </div>
</div>

<div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="row">
                <div class="col-lg-8">
                  <div class="well bs-component">
                    <form action = "ProsesTambahStatus.php" class="form-horizontal" method="post" enctype="multipart/form-data">
                     
                        <legend>Tambah Data Status</legend>
                        
                         <div class="form-group">
                          <label class="col-lg-3 control-label" for="inputEmail">Jenis Status</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "nama_status" id="nama_status" type="text" placeholder="Jenis Status">
                          </div>
                         </div>
                       
                        
                        </div>
                        <div class="form-group">
                          <div class="col-lg-8 col-lg-offset-3">
                           <button class="btn btn-primary" type="submit">Simpan</button>
                             <button class="btn btn-default" type="reset">Batal</button>
                            
                          </div>
                        
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>