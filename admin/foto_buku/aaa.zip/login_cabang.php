<?php

include "koneksi.php";

//mengenalkan variabel dari data yang di input di form login
$user	= $_POST['username'];
$pass	= $_POST['password'];

//cek pada tabel pendaftaran dimana no pendaftaran dan tanggal lahir sesuai dengan yang di input di form login
$login		=	mysqli_query($link,"SELECT * FROM tbkpp WHERE username='$user' AND password='$pass'");
$ketemu		=	mysqli_num_rows($login);//menghitung record yang sesuai dengan no pendaftaran atau tanggal lahir
$r			=	mysqli_fetch_array($login);//mengambil record berdasarkan index array atau nama field

//menggunakan percabangan
//Apabila username dan password ditemukan maka menjalankan perintah ini
if ($ketemu > 0){
	
	//session digunakan untuk menampung nilai sementara dalam sistem
	//memulai session
	session_start();

	//mendaftarkan session yang akan di tampung nilainya
	$_SESSION['kode_kpp']			= $r['kode_kpp'];
	$_SESSION['nama_kpp']			= $r['nama_kpp'];
  
	//jika berhasil link akan mengarah ke media calon siswa/halaman si calon siswa
	echo "
		<script>alert('Anda Berhasil Login. Selamat Datang $_SESSION[nama_kpp]'); 
		window.location = 'cabang/beranda'</script>
	";
}
//selain itu dia akan mengeksekusi atau jika salah login dia akan kembali ke halaman login
else{
    echo "
		<script>alert('Username atau Password Salah/Tidak Sesuai'); 
		window.location = 'masuk.html'</script>
	";
}
?>