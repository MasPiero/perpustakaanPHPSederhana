<?php

include "koneksi.php";


$username	= $_POST['username'];
$password	= $_POST['password'];

//cek pada tabel pendaftaran dimana no pendaftaran dan tanggal lahir sesuai dengan yang di input di form login
$login		=	mysqli_query($link,"SELECT * FROM tbadmin WHERE username='$username' AND password='$password'");
$ketemu		=	mysqli_num_rows($login);//menghitung record yang sesuai dengan no pendaftaran atau tanggal lahir
$r			=	mysqli_fetch_array($login);//mengambil record berdasarkan index array atau nama field

//menggunakan percabangan
//Apabila username dan password ditemukan maka menjalankan perintah ini
if ($ketemu > 0){
	
	//session digunakan untuk menampung nilai sementara dalam sistem
	//memulai session
	session_start();

	//mendaftarkan session yang akan di tampung nilainya
	$_SESSION['id']			= $r['id'];
	$_SESSION['username']			= $r['username'];
	$_SESSION['nama_admin']			= $r['nama_admin'];
	$_SESSION['status']			= $r['status'];
  
	//jika berhasil link akan mengarah ke media calon siswa/halaman si calon siswa
	echo "
		<script>alert('Anda Berhasil Login. Selamat Datang $_SESSION[username]'); 
		window.location = 'mimin/beranda'</script>
	";
}
//selain itu dia akan mengeksekusi atau jika salah login dia akan kembali ke halaman login
else{
    echo "
		<script>alert('Username atau Password Salah/Tidak Sesuai'); 
		window.location = 'index.html'</script>
	";
}
?>