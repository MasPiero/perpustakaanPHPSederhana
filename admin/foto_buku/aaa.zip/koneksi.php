<?php
$link= mysqli_connect( 'localhost', 'root', '');
$database = mysqli_select_db($link, 'db_kpp_baru');

?>
