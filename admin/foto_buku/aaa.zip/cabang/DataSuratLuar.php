 <div class="row">
      <div class="col-md-12">
        <h1 class="page-header">
            DataSurat Luar Kota <small><?php  echo $_SESSION['nama_kpp']  ?></small>
        </h1>
       </div>
</div>

            <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                        DataSurat Luar Kota
                        </div>
                        <div class="panel-body">
                           
              
                                    <?php
                             $tampil=mysqli_query ($link,"SELECT * FROM tbsuratluar LEFT JOIN tbkpp on tbsuratluar.kode_kpp = tbkpp.kode_kpp LEFT JOIN tbbagian on tbsuratluar.kode_bagian=tbbagian.kode_bagian LEFT JOIN tbstatus on tbsuratluar.id_status = tbstatus.id_status where tbsuratluar.kode_kpp = '$_SESSION[kode_kpp]' order by tbsuratluar.id_suratluar DESC");
                            $no=0;  
                             ?>
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr >
                                              <th>No</th>
                      <th>No. Resi</th>
                       <th>KPP</th>
                       <th>Bagian</th>
                        <th>No Surat</th>
                         <th>Tgl. Surat Masuk</th>
                         
                            <th>Qty</th>
                             <th>Nama Penerima</th>
                             <th>Status</th>
                             
                                <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while($data=mysqli_fetch_array($tampil))
                                             { $no++;
                                                ?>

                                            <tr>
                         
                          <td><?php echo $no;; ?></td>
                         
                          <td><?php echo $data['no_resi']; ?></td>
                           <td><?php echo $data['nama_kpp']; ?></td>
                            <td><?php echo $data['nama_bagian']; ?></td>
                             <td><?php echo $data['no_surat']; ?></td>
                              <td><?php echo tgl_indo( $data['tgl_masuk']); ?></td>
                             
                              <td><?php echo $data['qty']; ?></td>
                              <td><?php echo $data['tujuan_nama']; ?></td>
                               <td><?php 
                                if ($data['nama_status'] ==  "Terkirim")
                                  {echo "<span class='label label-primary'> $data[nama_status] </span>";}
                                 elseif ($data['nama_status'] ==  "Proses Kirim")
                                  {echo "<span class='label label-info'> $data[nama_status] </span>";}
                                  else
                                  { echo "<span class='label label-warning'> $data[nama_status] </span>";}
                               ?></td>
                               <td><a class="btn btn-info"   href="beranda.php?hal=DetailSuratLuar&id_suratluar=<?php echo $data['id_suratluar']  ?>"> <i class="fa fa-arrow-left"></i>Detail</a> 
                          </td>
                                               
                          
                          
                         </tr>
                                             <?php   
                                          }
                                          ?>
                                      
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
                 <br><br><br><br>  <br><br><br><br>  <br><br><br><br>  <br><br><br><br>  <br><br><br><br>  <br><br><br><br>
            </div>
                <!-- /. ROW  -->
            
                <!-- /. ROW  -->
            
                <!-- /. ROW  -->
            
                <!-- /. ROW  -->
        </div>
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
  
    
   

