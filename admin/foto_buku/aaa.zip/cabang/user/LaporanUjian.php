<?php
include "../../koneksi.php";

require('../../fpdf17/fpdf.php');
$tanggal_awal=$_POST['tanggal_awal'];
$tanggal_akhir=$_POST['tanggal_akhir'];
 session_start();
$_SESSION['kid'] = 'dosen';
$_SESSION['kij'] = 'T'; 
                    



$pdf = new FPDF('l','mm',array(210,297)); //L For Landscape / P For Portrait
$pdf->AddPage();
$pdf->setXY(135,2);
$pdf->setFont('Times','',18);
$pdf->Cell(32, 40, 'LAPORAN JADWAL UJIAN', 0, 0, 'C',0);
$pdf->ln(6);
$pdf->setFont('Times','',12);
$pdf->setXY(10,30);
$pdf->Cell(35,6,'NO UJIAN',1,0,'C');
$pdf->setXY(45,30);
$pdf->Cell(60,6,'TANGGAL UJIAN',1,0,'C');
$pdf->setXY(105,30);
$pdf->Cell(40,6,'RUANG',1,0,'C');
$pdf->setXY(145,30);
$pdf->Cell(25,6,'JAM MULAI',1,0,'C');
$pdf->setXY(170,30);
$pdf->Cell(25,6,'JAM AKHIR',1,0,'C');
$pdf->setXY(195,30);
$pdf->Cell(30,6,'KODE JADWAL.',1,0,'C');





$kueri = mysql_query("SELECT * FROM ujian where (tanggal_ujian BETWEEN '$tanggal_awal' AND '$tanggal_akhir') ");
  
while($data=mysql_fetch_array($kueri)){
$pdf->ln(6);

$pdf->Cell(35,6,'    '.$data['no_ujian'],1,0,'C');
$pdf->Cell(60,6,'    '.$data['tanggal_ujian'],1,0,'L');
$pdf->Cell(40,6,'    '.$data['ruang'],1,0,'C');
$pdf->Cell(25,6,'    '.$data['jam_mulai'],1,0,'C');
$pdf->Cell(25,6,'    '.$data['jam_akhir'],1,0,'C');
$pdf->Cell(30,6,'    '.$data['kode_jadwal'],1,0,'C');



}
$pdf->Output();

?>