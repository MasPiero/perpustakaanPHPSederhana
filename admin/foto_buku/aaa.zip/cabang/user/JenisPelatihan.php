 <div class="row">
      <div class="col-md-12">
        <h1 class="page-header">
            Data Jenis Pelatihan <small>American Standard</small>
        </h1>
       </div>
</div>

            <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                        Jenis Pelatihan
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                            <div class="text-left">
                            <a href="?hal=TambahJenisPelatihan" class="btn btn-sm btn-primary">Tambah Jenis Pelatihan <i class="fa fa-arrow-circle-right"></i></a>
                            <br><br>
              
                                    <?php
                                        $tampil=mysql_query ("select * FROM PELATIHAN ");
                                    ?>
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                       <tr >
                                            <th>Kode Pelatihan</th>
                                            <th>Jenis Pelatihan</th>
                                            <th>Materi Pelatihan</th>
                                            <th>Golongan Pelatihan</th>
                                            <th><center>Aksi</center></th>
                                            <th><center></center></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while($data=mysql_fetch_array($tampil))
                                             { ?>
                                             <tr>
                                            <td><?php echo $data['kode_pelatihan']; ?></td>
                                            <td><?php echo $data['jenis_pelatihan']; ?></td>
                                             <td><?php echo $data['materi_pelatihan']; ?></td>
                                            <td><?php echo $data['golongan_pelatihan']; ?></td>
                                          <td><a class="btn btn-sm btn-primary" href="beranda.php?hal=EditJenisPelatihan&kode_pelatihan=<?php echo $data['kode_pelatihan'];?>"><i class="fa fa-edit"></i> Edit</a></td>
                                          <td>
                                                <a class="btn btn-sm btn-danger" href="HapusPelatihan.php?kode_pelatihan=<?php echo $data['kode_pelatihan'];?>"><i class="fa fa-wrench"></i> Hapus</a></td></tr>
                                             <?php   
                                          }
                                          ?>
                                      
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>
                <!-- /. ROW  -->
            
                <!-- /. ROW  -->
            
                <!-- /. ROW  -->
            
                <!-- /. ROW  -->
        </div>
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
  
    
   

