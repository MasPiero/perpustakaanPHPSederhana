<?php
if  ($_GET['hal']=='beranda')
	{include "beranda.php";}

	
else if  ($_GET['hal']=='DataKaryawan')
	{include "DataKaryawan.php";}
else if  ($_GET['hal']=='DataTrainer')
	{include "DataTrainer.php";}
else if  ($_GET['hal']=='Depan')
	{include "Depan.php";}
else if  ($_GET['hal']=='Table')
	{include "Table.php";}
else if  ($_GET['hal']=='DetailKaryawan')
	{include "DetailKaryawan.php";}
else if  ($_GET['hal']=='TambahKaryawan')
	{include "TambahKaryawan.php";}
else if  ($_GET['hal']=='EditKaryawan')
	{include "EditKaryawan.php";}
else if  ($_GET['hal']=='DataPeserta')
	{include "DataPeserta.php";}
else if  ($_GET['hal']=='JenisPelatihan')
	{include "JenisPelatihan.php";}
else if  ($_GET['hal']=='EditJenisPelatihan')
	{include "EditJenisPelatihan.php";}
else if  ($_GET['hal']=='JadwalPelatihan')
	{include "JadwalPelatihan.php";}
else if  ($_GET['hal']=='EditTrainer')
	{include "EditTrainer.php";}
else if  ($_GET['hal']=='TambahTrainer')
	{include "TambahTrainer.php";}
else if  ($_GET['hal']=='TambahJenisPelatihan')
	{include "TambahJenisPelatihan.php";}
else if  ($_GET['hal']=='TambahPelatihan')
	{include "TambahPelatihan.php";}
else if  ($_GET['hal']=='LihatPeserta')
	{include "LihatPeserta.php";}
else if  ($_GET['hal']=='DataKategoriSoal')
	{include "DataKategoriSoal.php";}
else if  ($_GET['hal']=='TambahKategoriSoal')
	{include "TambahKategoriSoal.php";}
else if  ($_GET['hal']=='DataSoal')
	{include "DataSoal.php";}
else if  ($_GET['hal']=='DetailSoal')
	{include "DetailSoal.php";}
else if  ($_GET['hal']=='TambahSoal')
	{include "TambahSoal.php";}
else if  ($_GET['hal']=='JadwalUjian')
	{include "JadwalUjian.php";}
else if  ($_GET['hal']=='TambahJadwalUjian')
	{include "TambahJadwalUjian.php";}
else if  ($_GET['hal']=='EditJadwalUjian')
	{include "EditJadwalUjian.php";}
else if  ($_GET['hal']=='HasilTest')
	{include "HasilTest.php";}
	
else if  ($_GET['hal']=='TambahJadwalPelatihan')
	{include "TambahJadwalPelatihan.php";}
else if  ($_GET['hal']=='PesertaUjian')
	{include "PesertaUjian.php";}
else if  ($_GET['hal']=='InputTest')
	{include "InputTest.php";}
else if  ($_GET['hal']=='Pengaturan')
	{include "Pengaturan.php";}
else if  ($_GET['hal']=='Laporan')
	{include "Laporan.php";}
?>
