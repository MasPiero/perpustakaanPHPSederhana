<?php
include "../../koneksi.php";
$kode_trainer = $_GET['kode_trainer'];
$query = mysql_query("SELECT * FROM tbtrainer WHERE kode_trainer='$kode_trainer'");
while($data = mysql_fetch_array($query)){
  ?>
          
            <div class="panel panel-defautl">
              <div class="panel-heading">
                <h3 class="panel-title"><i class="fa fa-user"></i> Edit Data Trainer </h3>
              </div>
              <div class="panel-body">
                 <div class="table-responsive">
                  
    <form action="ProsesEditTrainer.php" method="post">
    <table class="table table-condensed">
    
      <tr>
        <td><label for="">Kode Trainer</label></td>
        <td><input name="kode_trainer" type="text" readonly class="form-control" value="<?php echo $data ['kode_trainer']?>" ></td>
      </tr>
      <tr>
        <td><label for="">Nama Trainer</label></td>
        <td><input name="nama_trainer" type="text" class="form-control" value="<?php echo $data ['nama_trainer']?>"></td>
      </tr>
      <tr>
        <td><label for="">Alamat Trainerr</label></td>
        <td><input name="alamat" type="text" class="form-control" value="<?php echo $data ['alamat']?>"> </td>
      </tr>
      <tr>
        <td><label for="">No Telp</label></td>
        <td><input name="no_telp" type="text" class="form-control" value="<?php echo $data ['no_telp']?>"</td>
      </tr>
      <tr>
        <td><label for="">Kode Materi</label></td>
        <td><input name="email" type="text" class="form-control" value="<?php echo $data ['email']?>"</td>
      </tr>
      <tr>
        <td><input type="submit" value="Update Data"  name="update" class="btn btn-sm btn-primary"/>&nbsp;<a href="beranda.php?hal=DataTrainer" class="btn btn-sm btn-primary">Kembali</a></td>
        </tr>
    </table>
    </form>
    <?php
    }
      ?>
                   </div>
                
              </div> 
            </div>
          </div>
        </div><!-- /.row --> 
      </div><!-- /#page-wrapper -->

    </div><!-- /#wrapper -->

    <!-- JavaScript -->
    <script src="js/jquery-1.10.2.js"></script>
    <script src="js/bootstrap.js"></script>

    <!-- Page Specific Plugins -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="http://cdn.oesmith.co.uk/morris-0.4.3.min.js"></script>
    <script src="js/morris/chart-data-morris.js"></script>
    <script src="js/tablesorter/jquery.tablesorter.js"></script>
    <script src="js/tablesorter/tables.js"></script>

 