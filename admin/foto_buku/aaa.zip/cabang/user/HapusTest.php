<?php 
include('../../koneksi.php');
$no_ujian = $_GET['no_ujian'];
$query = mysql_query("delete from ujian  where no_ujian='$no_ujian'") or die(mysql_error());

 echo "<meta http-equiv='refresh' content='0; url=beranda.php?hal=HasilTest'>";
?>