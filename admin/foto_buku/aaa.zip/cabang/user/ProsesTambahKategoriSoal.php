<?php

include "../../koneksi.php";
	
	$kode_materi		= $_POST['kode_materi'];
	$jumlah_soal		= $_POST['jumlah_soal'];

	$cek_dulu	=	mysql_num_rows(mysql_query("SELECT kode_materi FROM tbkategori_soal WHERE kode_materi='$_POST[kode_materi]'"));

if ($cek_dulu > 0){
	echo "<script>window.alert('Materi Ini Sudah Dikategorikan')</script>";
	echo "<meta http-equiv='refresh' content='0; url=beranda.php?hal=TambahKategoriSoal'>";
	

}
else{	

	$query =mysql_query("INSERT INTO tbkategori_soal VALUES ('','$kode_materi','$jumlah_soal')");
	if($query){
		 echo "<script>window.alert('Data Kategori Berhasil Disimpan')</script>";
 		 echo "<meta http-equiv='refresh' content='0; url=beranda.php?hal=DataKategoriSoal'>";
	}
	
}



?>