 <div class="row">
      <div class="col-md-12">
        <h1 class="page-header">
            Data Trainer <small>American Standard</small>
        </h1>
       </div>
</div>

            <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                        Data Trainer
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                            <div class="text-left">
                            <a href="?hal=TambahTrainer" class="btn btn-sm btn-primary">Tambah Trainer <i class="fa fa-arrow-circle-right"></i></a>
                            <br><br>

              
                                    <?php

                                        $tampil=mysql_query ("SELECT * FROM tbtrainer ");
                                    ?>
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr >
                                            <th>Kode Trainer</th>
                                            <th>Nama Trainer</th>
                                            <th>Alamat</th>
                                            <th>No. telp</th>
                                            <th>Email</th>
                                            <th><center>Aksi</center></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while($data=mysql_fetch_array($tampil))
                                             { ?>
                                            <tr>
                                            <td><?php echo $data['kode_trainer']; ?></td>
                                            <td><?php echo $data['nama_trainer']; ?></td>
                                             <td><?php echo $data['alamat']; ?></td>
                                            <td><?php echo $data['no_telp']; ?></td>
                                            <td><?php echo $data['email']; ?></td>
                                          <td><a class="btn btn-sm btn-primary" href="beranda.php?hal=EditTrainer&kode_trainer=<?php echo $data['kode_trainer'];?>"><i class="fa fa-edit"></i> Edit</a>
                                                <a class="btn btn-sm btn-danger" href="HapusTrainer.php?kode_trainer=<?php echo $data['kode_trainer'];?>"><i class="fa fa-wrench"></i> Hapus</a></td></tr>
                                             <?php   
                                          }
                                          ?>
                                      
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>
                <!-- /. ROW  -->
            
                <!-- /. ROW  -->
            
                <!-- /. ROW  -->
            
                <!-- /. ROW  -->
        </div>
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
  
    
   

