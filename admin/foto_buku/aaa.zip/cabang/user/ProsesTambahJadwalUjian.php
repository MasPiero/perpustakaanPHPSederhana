<?php

include "../../koneksi.php";
	$no_ujian			= $_POST['no_ujian'];
	$tanggal_ujian		= $_POST['tanggal_ujian'];
	$ruang				= $_POST['ruang'];
	$jam_mulai			= $_POST['jam_mulai'];
	$jam_akhir			= $_POST['jam_akhir'];
	$kode_jadwal		= $_POST['kode_jadwal'];

$cekdata="SELECT kode_jadwal FROM ujian where kode_jadwal = '$kode_jadwal' ";
$ada=mysql_query($cekdata) or die(mysql_error());

if(mysql_num_rows($ada)>0){
	echo "<script>window.alert('Ujian Untuk Kode ini Sudah ada')</script>";
	echo "<meta http-equiv='refresh' content='0; url=beranda.php?hal=JadwalUjian'>";

}else{



	$query =mysql_query("INSERT INTO ujian VALUES ('$no_ujian','$tanggal_ujian','$ruang','$jam_mulai','$jam_akhir','$kode_jadwal')");
	if($query){
		 echo "<script>window.alert('Data Ujian Berhasil Disimpan')</script>";
 		 echo "<meta http-equiv='refresh' content='0; url=beranda.php?hal=JadwalUjian'>";
	}
	
}



?>