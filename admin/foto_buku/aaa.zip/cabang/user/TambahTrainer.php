<div class="row">
  <div class="col-md-12">
    <h1 class="page-header">
            Tambah Trainer <small>American Standard</small>
    </h1>
</div>

<div class="col-lg-12">
            <div class="panel panel-default">
              <div class="panel-heading">
                <h3 class="panel-title"><i class="fa fa-user"></i> Tambah Data Trainer </h3>
              </div>
              <div class="panel-body">
                 <div class="table-responsive">
                  
    <form action="ProsesTambahTrainer.php" method="post">
    <table class="table table-condensed">
   
      <tr>
        <td><label for="">Kode Trainer</label></td>
        <td><input name="kode_trainer" type="text" class="form-control" id="kode_trainer" placeholder="Kode Trainer" required/></td>
      </tr>
      <tr>
        <td><label for="">Nama Trainer</label></td>
        <td><input name="nama_trainer" type="text" class="form-control" id="nama_trainer" placeholder="Nama Trainer" required/></td>
      </tr>
      <tr>
        <td><label for="">Alamat</label></td>
        <td><input name="alamat" type="text" class="form-control" id="alamat" placeholder="Alamat Trainer" required/></td>
      </tr>
      <tr>
        <td><label for="no_rek">No Telp</label></td>
        <td><input name="no_telp" type="text" class="form-control" id="no_telp" placeholder="No Telepon" required/></td>
      </tr>
       <tr>
        <td><label for="no_rek">Email</label></td>
        <td><input name="email" type="text" class="form-control" id="email" placeholder="Email" required/></td>
      </tr>
      
      <tr>
        <td><input type="submit" value="Simpan Data"  class="btn btn-sm btn-primary"/>&nbsp;<a href="beranda.php?hal=DataTrainer" class="btn btn-sm btn-primary">Kembali</a></td>
        </tr>
    </table>
    </form>
                   </div>
                
              
                </div>
              </div> 
            </div>
          </div>
        </div><!-- /.row --> 