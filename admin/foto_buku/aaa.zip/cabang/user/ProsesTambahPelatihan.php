<?php

include "../../koneksi.php";
	$no_pelatihan				= $_POST['no_pelatihan'];
	$tanggal_pelatihan			= $_POST['tanggal_pelatihan'];
	$kode_materi				= $_POST['kode_materi'];
	$kode_trainer				= $_POST['kode_trainer'];

	

	$query =mysql_query("INSERT INTO tbpelatihan VALUES ('$no_pelatihan','$tanggal_pelatihan','$kode_materi','$kode_trainer','0','Terlaksana')");
	if($query){
		 echo "<script>window.alert('Jadwal Pelatihan Berhasil Disimpan')</script>";
 		 echo "<meta http-equiv='refresh' content='0; url=beranda.php?hal=JadwalPelatihan'>";
	}
	




?>