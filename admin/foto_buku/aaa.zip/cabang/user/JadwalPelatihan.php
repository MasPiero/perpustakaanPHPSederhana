
  <?php
  error_reporting(0);
  session_start();
  
 
?>

       



            <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                        Data Pelatihan
                        </div>
                        <div class="panel-body">
                           
                            <div class="table-responsive">
                            <div class="text-left">
                            <a href="?hal=TambahJadwalPelatihan" class="btn btn-sm btn-primary">Tambah Jadwal Pelatihan <i class="fa fa-arrow-circle-right"></i></a>
                            <div class="text-left">
                            <br><br>
                            
                           
              
                                    <?php
                                        $tampil=mysql_query ("SELECT * FROM jadwal_pelatihan");
                                    ?>
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr >
                                            <th>Kode Jadwal</th>
                                            <th>Tanggal Pelatihan</th>
                                            <th>Ruang</th>
                                            <th>Jam Mulai</th>
                                            <th>Jam Akhir</th>
                                            <th>Kode Pelatihan</th>
                                            <th>Kode Trainer</th>
                                            <th><center>Aksi</center></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while($data=mysql_fetch_array($tampil))
                                             { ?>
                                            <tr>
                                            <td><?php echo $data['kode_jadwal']; ?></td>
                                            <td><?php echo $data['tanggal_pelatihan']; ?></td>
                                             <td><?php echo $data['ruang']; ?></td>
                                            <td><?php echo $data['jam_mulai']; ?></td>
                                            <td><?php echo $data['jam_akhir']; ?></td>
                                            <td><?php echo $data['kode_pelatihan']; ?></td>
                                            <td><?php echo $data['kode_trainer']; ?></td>
                                            
                                            
                                        

                                         <td> <a class="btn btn-sm btn-primary" href="beranda.php?hal=LihatPeserta&kode_jadwal=<?php echo $data['kode_jadwal'];?>"><i class="fa fa-user"></i> Lihat Peserta</a></td>
                                                
                                             <?php   
                                          }
                                          ?>
                                      
                                    </tbody>
                                </table>
                             
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>
                <!-- /. ROW  -->
            
                <!-- /. ROW  -->
            
                <!-- /. ROW  -->
            
                <!-- /. ROW  -->
        </div>
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
  
  
    
   

