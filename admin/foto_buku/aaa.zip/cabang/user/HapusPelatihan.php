<?php 
include('../../koneksi.php');
$kode_pelatihan = $_GET['kode_pelatihan'];
$query = mysql_query("delete from pelatihan where kode_pelatihan='$kode_pelatihan'") or die(mysql_error());

 echo "<meta http-equiv='refresh' content='0; url=beranda.php?hal=JenisPelatihan'>";
?>