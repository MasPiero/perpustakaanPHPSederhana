 <div class="row">
      <div class="col-md-12">
        <h1 class="page-header">
            Data Karyawan <small>Standart American</small>
        </h1>
       </div>
</div>

            <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                        Data Karyawan
                        </div>
                        <div class="panel-body">
                           
              
                                    <?php
                                        $tampil=mysql_query ("select nik, nama, tempat_lahir,tanggal_lahir,departement from tbkaryawan order by nik ASC");
                                    ?>
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr >
                                            <th>NIK</th>
                                            <th>Nama Karyawan</th>
                                            <th>Tempat lahir</th>
                                            <th>Tanggal lahir</th>
                                            <th>Departement</th>
                                            <th><center>Aksi</center></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while($data=mysql_fetch_array($tampil))
                                             { ?>
                                            <tr>
                                            <td><?php echo $data['nik']; ?></td>
                                            <td><?php echo $data['nama']; ?></td>
                                             <td><?php echo $data['tempat_lahir']; ?></td>
                                            <td><?php echo $data['tanggal_lahir']; ?></td>
                                            <td><?php echo $data['departement']; ?></td>
                                          <td><a class="btn btn-sm btn-primary" href="beranda.php?hal=EditKaryawan&nik=<?php echo $data['nik'];?>"><i class="fa fa-edit"></i> Edit</a>
                                                <a class="btn btn-sm btn-danger" href="HapusKaryawan.php?nik=<?php echo $data['nik'];?>"><i class="fa fa-wrench"></i> Hapus</a></td></tr>
                                             <?php   
                                          }
                                          ?>
                                      
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>
                <!-- /. ROW  -->
            
                <!-- /. ROW  -->
            
                <!-- /. ROW  -->
            
                <!-- /. ROW  -->
        </div>
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
  
    
   

