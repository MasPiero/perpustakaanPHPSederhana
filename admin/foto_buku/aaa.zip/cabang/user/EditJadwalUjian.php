<?php
include "../../koneksi.php";
$no_ujian = $_GET['no_ujian'];
$query = mysql_query("SELECT * FROM ujian WHERE no_ujian='$no_ujian'");
while($data = mysql_fetch_array($query)){
  ?>
          
            <div class="panel panel-defautl">
              <div class="panel-heading">
                <h3 class="panel-title"><i class="fa fa-user"></i> Edit Jadwal Ujian </h3>
              </div>
              <div class="panel-body">
                 <div class="table-responsive">
                  
    <form action="ProsesEditJadwalUjian.php" method="post">
    <table class="table table-condensed">
    
      <tr>
        <td><label for="">No Ujian</label></td>
        <td><input name="no_ujian" type="text" readonly class="form-control" value="<?php echo $data ['no_ujian']?>" ></td>
      </tr>
      <tr>
        <td><label for="">Tanggal Ujian</label></td>
        <td><input name="tanggal_ujian" type="date" class="form-control" value="<?php echo $data ['tanggal_ujian']?>"></td>
      </tr>
      <tr>
        <td><label for="">ruang</label></td>
         <td><input name="ruang" type="text" class="form-control" rows="5"  value="<?php echo $data ['ruang']?>"></td>
       </tr>
       <tr>
        <td><label for="">Jam Mulai</label></td>
         <td><input name="jam_mulai" type="text" class="form-control" rows="5"  value="<?php echo $data ['jam_mulai']?>"></td>
       </tr>
       <tr>
        <td><label for="">Jam Akhir</label></td>
         <td><input name="jam_akhir" type="text" class="form-control" rows="5"  value="<?php echo $data ['jam_akhir']?>"></td>
       </tr>
      <tr>
      <td><label > Kode Jadwal</label></td>
                    <td> <?php
                              include "../../koneksi.php";

                            echo "<select class='col-sm-6' name='kode_jadwal'>";
                            $tampil = mysql_query("SELECT * FROM ujian ");
                            
                            while($w=mysql_fetch_array($tampil))
                                  {
                          echo "<option value=$w[kode_jadwal] selected>$w[kode_jadwal]</option>";        
                            }
                             echo "</select>";
                            ?>
      </tr>
      
      <tr>
        <td><input type="submit" value="Update Data"  name="update" class="btn btn-sm btn-primary"/>&nbsp;<a href="beranda.php?hal=JadwalUjian" class="btn btn-sm btn-primary">Kembali</a></td>
        </tr>
    </table>
    </form>
    <?php
    }
      ?>
                   </div>
                
              </div> 
            </div>
          </div>
        </div><!-- /.row --> 
      </div><!-- /#page-wrapper -->

    </div><!-- /#wrapper -->

    <!-- JavaScript -->
    <script src="js/jquery-1.10.2.js"></script>
    <script src="js/bootstrap.js"></script>

    <!-- Page Specific Plugins -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="http://cdn.oesmith.co.uk/morris-0.4.3.min.js"></script>
    <script src="js/morris/chart-data-morris.js"></script>
    <script src="js/tablesorter/jquery.tablesorter.js"></script>
    <script src="js/tablesorter/tables.js"></script>

 