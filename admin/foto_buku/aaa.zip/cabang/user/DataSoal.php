<?php
include "../../koneksi.php";
?>


 <div class="row">
      <div class="col-md-12">
        <h1 class="page-header">
            Data Soal <small>American Standard</small>
        </h1>
       </div>
</div>

            <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                        Data  Soal
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                            <div class="text-left">
                            <a href="?hal=TambahSoal" class="btn btn-sm btn-primary">Tambah Soal <i class="fa fa-arrow-circle-right"></i></a>
                            <br><br>
              
                                    <?php
                                        $tampil=mysql_query ("select * from tbsoal ");
                                    ?>
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr >
                                            <th hidden=""> id Soal </th>
                                            <th>Nama Materi</th>
                                            <th>Pertanyaan</th>
                                            <th>Jawaban</th>
                                            <th>Aksi</th>
                                        </tr>

                                    </thead>

                                    <tbody>
                                        <?php while($data=mysql_fetch_array($tampil))
                                             { ?>
                                            <tr>
                                            <td hidden><?php echo $data['kode_soal']; ?></td>
                                            <td><?php echo $data['nama_materi']; ?></td>
                                            <td><?php echo $data['pertanyaan']; ?></td>
                                             <td><?php echo $data['jawaban'];?></td>
                                           
                                          <td>
                                                <a class="btn btn-sm btn-info" href="Beranda.php?hal=DetailSoal&kode_soal=<?php echo $data['kode_soal'];?>"><i class="fa fa-edit"></i> Detail</a></td></tr>
                                             <?php   
                                          }
                                          ?>
                                      
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>
                <!-- /. ROW  -->
            
                <!-- /. ROW  -->
            
                <!-- /. ROW  -->
            
                <!-- /. ROW  -->
        </div>
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
  
    
   

