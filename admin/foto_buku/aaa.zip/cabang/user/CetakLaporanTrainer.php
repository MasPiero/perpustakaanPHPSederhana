<?php
include "../../koneksi.php";

require('../../fpdf17/fpdf.php');

 session_start();
$_SESSION['kid'] = 'dosen';
$_SESSION['kij'] = 'T'; 
                    



$pdf = new FPDF('L','mm',array(210,297)); //L For Landscape / P For Portrait
$pdf->AddPage();
$pdf->setXY(135,2);
$pdf->setFont('Times','',18);
$pdf->Cell(32, 40, 'LAPORAN TRAINER', 0, 0, 'C',0);
$pdf->ln(6);
$pdf->setFont('Times','',12);
$pdf->setXY(10,30);
$pdf->Cell(35,6,'KODE TRAINER',1,0,'C');
$pdf->setXY(45,30);
$pdf->Cell(60,6,'NAMA TRAINER',1,0,'C');
$pdf->setXY(105,30);
$pdf->Cell(40,6,'ALAMAT',1,0,'C');
$pdf->setXY(145,30);
$pdf->Cell(50,6,'NO TELP',1,0,'C');
$pdf->setXY(195,30);
$pdf->Cell(40,6,'EMAIL',1,0,'C');







$kueri = mysql_query("SELECT * FROM tbtrainer  ");
  
while($data=mysql_fetch_array($kueri)){
$pdf->ln(6);

$pdf->Cell(35,6,'    '.$data['kode_trainer'],1,0,'L');
$pdf->Cell(60,6,'    '.$data['nama_trainer'],1,0,'L');
$pdf->Cell(40,6,'    '.$data['alamat'],1,0,'C');
$pdf->Cell(50,6,'    '.$data['no_telp'],1,0,'C');
$pdf->Cell(40,6,'    '.$data['email'],1,0,'C');




}
$pdf->Output();

?>