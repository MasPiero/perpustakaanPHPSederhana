<?php

include "../../koneksi.php";
	$kode_jadwal		= $_POST['kode_jadwal'];
	$tanggal_pelatihan	= $_POST['tanggal_pelatihan'];
	$ruang				= $_POST['ruang'];
	$jam_mulai			= $_POST['jam_mulai'];
	$jam_akhir			= $_POST['jam_akhir'];
	$kode_pelatihan		= $_POST['kode_pelatihan'];
	$kode_trainer		= $_POST['kode_trainer'];
	

	$query =mysql_query("INSERT INTO jadwal_pelatihan VALUES ('$kode_jadwal','$tanggal_pelatihan','$ruang','$jam_mulai','$jam_akhir','$kode_pelatihan','$kode_trainer')");
	if($query){
		 echo "<script>window.alert('Data Jadwal Pelatihan Berhasil Disimpan')</script>";
 		 echo "<meta http-equiv='refresh' content='0; url=beranda.php?hal=JadwalPelatihan'>";
	}
	




?>