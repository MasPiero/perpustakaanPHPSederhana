<div class="row">
  <div class="col-md-12">
    <h1 class="page-header">
            Ganti Password <small>American Standard</small>
    </h1>
</div>

<div class="col-lg-12">
            <div class="panel panel-default">
              <div class="panel-heading">
                <h3 class="panel-title"><i class="fa fa-gear"></i> Ganti Password </h3>
              </div>
              <div class="panel-body">
                 <div class="table-responsive">
                  
    <form action="ProsesGantiPass.php" method="post">
    <table class="table table-condensed">
   
      <tr>
        <td><label for="">Password Lama</label></td>
        <td><input name="pass_lama" type="password" class="form-control" id="pass_lama" placeholder="Masukan Password Lama" required/></td>
      </tr>
      <tr>
        <td><label for="">Password Baru</label></td>
        <td><input name="pass_baru" type="password" class="form-control" id="pass_baru" placeholder="Massukan Password Baru" required/></td>
      </tr>
      <tr>
        <td><label for="">Konfirmasi Password</label></td>
        <td><input name="konfirmasi" type="password" class="form-control" id="konfirmasi" placeholder="Ulangi Password Baru " required/></td>
      </tr>
     
      <tr>
        <td><input type="submit" value="Ganti Password"  class="btn btn-sm btn-primary"/>&nbsp;<a href="beranda.php?hal=Depan" class="btn btn-sm btn-primary">Kembali</a></td>
        </tr>
    </table>
    </form>
                   </div>
                
              
                </div>
              </div> 
            </div>
          </div>
        </div><!-- /.row --> 