<?php 
include('../../koneksi.php');
$nik = $_GET['nik'];
$query = mysql_query("delete from tbkaryawan where nik='$nik'") or die(mysql_error());

 echo "<meta http-equiv='refresh' content='0; url=beranda.php?hal=DataKaryawan'>";
?>