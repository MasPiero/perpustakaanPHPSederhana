
  <?php
  error_reporting(0);
  session_start();
  
 
?>

            <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                        Jadwal Ujian
                        </div>
                        <div class="panel-body">
                           
                            <div class="table-responsive">
                            <div class="text-left">
                            <a href="?hal=TambahJadwalUjian" class="btn btn-sm btn-primary">Tambah Jadwal Ujian <i class="fa fa-arrow-circle-right"></i></a>
                            <div class="text-left">
                            <br><br>
                            
                           
                                    <?php
                                        $tampil=mysql_query ("SELECT * FROM ujian");
                                    ?>
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr >
                                            <th>No Ujian</th>
                                            <th>Tanggal Ujian</th>
                                            <th>Ruang</th>
                                            <th>Jam Mulai</th>
                                            <th>Jam Akhir</th>
                                            <th>Kode Jadwal</th>
                                            <th><center>Aksi</center></th>
                                             <th><center></center></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while($data=mysql_fetch_array($tampil))
                                             { ?>
                                            <tr>
                                            <td><?php echo $data['no_ujian']; ?></td>
                                            <td><?php echo $data['tanggal_ujian']; ?></td>
                                             <td><?php echo $data['ruang']; ?></td>
                                            <td><?php echo $data['jam_mulai']; ?></td>
                                            <td><?php echo $data['jam_akhir']; ?></td>
                                            <td><?php echo $data['kode_jadwal']; ?></td>
                                            
                                            
                                        

                                         <td> <a class="btn btn-sm btn-primary" href="beranda.php?hal=EditJadwalUjian&no_ujian=<?php echo $data['no_ujian'];?>"><i class="fa fa-user"></i> Edit</a></td>
                                          <td> <a class="btn btn-sm btn-danger" href="HapusJadwalUjian.php?no_ujian=<?php echo $data['no_ujian'];?>"><i class="fa fa-wrench"></i> Hapus</a></td>
                                                
                                             <?php   
                                          }
                                          ?>
                                      
                                    </tbody>
                                </table>
                             
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>
                <!-- /. ROW  -->
            
                <!-- /. ROW  -->
            
                <!-- /. ROW  -->
            
                <!-- /. ROW  -->
        </div>
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
  
  
    
   

