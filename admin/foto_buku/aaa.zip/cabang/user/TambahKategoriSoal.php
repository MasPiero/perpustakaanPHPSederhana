<div class="row">
  <div class="col-md-12">
    <h1 class="page-header">
            Tambah Kategori Soal <small>American Standard</small>
    </h1>
</div>

<div class="col-lg-12">
            <div class="panel panel-default">
              <div class="panel-heading">
                <h3 class="panel-title"><i class="fa fa-user"></i> Tambah Kategori Soal </h3>
              </div>
              <div class="panel-body">
                 <div class="table-responsive">
                  
    <form action="ProsesTambahKategoriSoal.php" method="post">
    <table class="table table-condensed">
   
      <tr>
      <td><label > Nama Materi</label></td>
                    <td> <?php
                              include "../koneksi.php";

                            echo "<select class='col-sm-6' name='kode_materi'>";
                            $tampil = mysql_query("SELECT * FROM tbmateri_pelatihan ");
                            
                            while($w=mysql_fetch_array($tampil))
                                  {
                          echo "<option value=$w[kode_materi] selected>$w[nama_materi]</option>";        
                            }
                             echo "</select>";
                            ?>
      </tr>
        <td><label for="">Jumlah Soal</label></td>
        <td><input name="jumlah_soal" type="text" class="form-control" id="jumlah_soal" placeholder="Jumlah Soal" required/></td>
      </tr>
      
        <td><input type="submit" value="Tambah kategori"  class="btn btn-sm btn-primary"/>&nbsp;<a href="beranda.php?hal=DataKategoriSoal" class="btn btn-sm btn-primary">Kembali</a></td>
        </tr>
    </table>
    </form>
                   </div>
                
              
                </div>
              </div> 
            </div>
          </div>
        </div><!-- /.row --> 