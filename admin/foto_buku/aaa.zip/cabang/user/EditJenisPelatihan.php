<?php
include "../../koneksi.php";
$kode_pelatihan = $_GET['kode_pelatihan'];
$query = mysql_query("SELECT * FROM pelatihan WHERE kode_pelatihan='$kode_pelatihan'");
while($data = mysql_fetch_array($query)){
  ?>
          
            <div class="panel panel-defautl">
              <div class="panel-heading">
                <h3 class="panel-title"><i class="fa fa-user"></i> Edit Data Pelatihan </h3>
              </div>
              <div class="panel-body">
                 <div class="table-responsive">
                  
    <form action="ProsesEditJenisPelatihan.php" method="post">
    <table class="table table-condensed">
    
      <tr>
        <td><label for="">Kode Pelatihan</label></td>
        <td><input name="kode_pelatihan" type="text" readonly class="form-control" value="<?php echo $data ['kode_pelatihan']?>" ></td>
      </tr>
      <tr>
        <td><label for="">Nama Jenis Pelatihan</label></td>
        <td><input name="jenis_pelatihan" type="text" class="form-control" value="<?php echo $data ['jenis_pelatihan']?>"></td>
      </tr>
      <tr>
        <td><label for="">Materi Pelatihan</label></td>
         <td><input name="materi_pelatihan" type="text" class="form-control" rows="5"  value="<?php echo $data ['materi_pelatihan']?>"></td>
       </tr>
       <tr>
        <td><label for="">Golongan</label></td>
         <td><input name="golongan" type="text" class="form-control" rows="5"  value="<?php echo $data ['golongan_pelatihan']?>"></td>
       </tr>
      
      <tr>
        <td><input type="submit" value="Update Data"  name="update" class="btn btn-sm btn-primary"/>&nbsp;<a href="beranda.php?hal=MateriPelatihan" class="btn btn-sm btn-primary">Kembali</a></td>
        </tr>
    </table>
    </form>
    <?php
    }
      ?>
                   </div>
                
              </div> 
            </div>
          </div>
        </div><!-- /.row --> 
      </div><!-- /#page-wrapper -->

    </div><!-- /#wrapper -->

    <!-- JavaScript -->
    <script src="js/jquery-1.10.2.js"></script>
    <script src="js/bootstrap.js"></script>

    <!-- Page Specific Plugins -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="http://cdn.oesmith.co.uk/morris-0.4.3.min.js"></script>
    <script src="js/morris/chart-data-morris.js"></script>
    <script src="js/tablesorter/jquery.tablesorter.js"></script>
    <script src="js/tablesorter/tables.js"></script>

 