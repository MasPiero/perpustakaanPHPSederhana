<?php
include "../../koneksi.php";
$kode_soal = $_GET['kode_soal'];
  $query = mysql_query("SELECT * FROM tbsoal WHERE kode_soal='$kode_soal'");
  while($data = mysql_fetch_array($query)){
  ?>
          
            <div class="panel panel-defautl">
              <div class="panel-heading">
                <h3 class="panel-title"><i class="fa fa-user"></i> Detail Soal </h3>
              </div>
              <div class="panel-body">
                 <div class="table-responsive">
                  
    <form action="ProsesEditKaryawan.php" method="post">
    <table class="table table-condensed">
    
      <tr>
        <td><label for="">Kode Soal</label></td>
        <td><input name="kode_soal" type="text" readonly class="form-control" value="<?php echo $data ['kode_soal']?>" ></td>
      </tr>
      <tr>
        <td><label for="">Nama Materi</label></td>
        <td><input name="nama_materi" type="text" class="form-control" value="<?php echo $data ['nama_materi']?>"></td>
      </tr>
      <tr>
        <td><label for="">Pertanyaan</label></td>
        <td><input name="pertanyaan" type="text" class="form-control" value="<?php echo $data ['pertanyaan']?>"> </td>
      </tr>
      <tr>
        <td><label for="">Jawaban A</label></td>
        <td><input name="jawaban_a" type="text" class="form-control" value="<?php echo $data ['jawaban_a']?>"</td>
      </tr>
      <tr>
        <td><label for="">Jawaban B</label></td>
        <td><input name="jawaban_b" type="text" class="form-control" value="<?php echo $data ['jawaban_b']?>"</td>
      </tr>
      <tr>
      <tr>
        <td><label for="">Jawaban C</label></td>
        <td><input name="jawaban_c" type="text" class="form-control" value="<?php echo $data ['jawaban_c']?>"</td>
      </tr>
      <tr>
        <td><label for="">Jawaban D</label></td>
        <td><input name="jawaban_d" type="text" class="form-control" value="<?php echo $data ['jawaban_d']?>"</td>
      </tr>
      <tr>
        <td><label for="">Jawaban Benar</label></td>
        <td><input name="jawaban" type="text" class="form-control" value="<?php echo $data ['jawaban']?>"</td>
      </tr>
      <tr>
      <tr>
      <tr>
        <td>;<a href="beranda.php?hal=DataSoal" class="btn btn-sm btn-primary">Kembali</a></td>
        </tr>
    </table>
    </form>
    <?php
    }
      ?>
                   </div>
                
              </div> 
            </div>
          </div>
        </div><!-- /.row --> 
      </div><!-- /#page-wrapper -->

    </div><!-- /#wrapper -->

    <!-- JavaScript -->
    <script src="js/jquery-1.10.2.js"></script>
    <script src="js/bootstrap.js"></script>

    <!-- Page Specific Plugins -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="http://cdn.oesmith.co.uk/morris-0.4.3.min.js"></script>
    <script src="js/morris/chart-data-morris.js"></script>
    <script src="js/tablesorter/jquery.tablesorter.js"></script>
    <script src="js/tablesorter/tables.js"></script>

 