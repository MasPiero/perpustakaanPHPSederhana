<?php 
include('../../koneksi.php');
$kode_trainer = $_GET['kode_trainer'];
$query = mysql_query("delete from tbtrainer where kode_trainer='$kode_trainer'") or die(mysql_error());

 echo "<meta http-equiv='refresh' content='0; url=beranda.php?hal=DataTrainer'>";
?>