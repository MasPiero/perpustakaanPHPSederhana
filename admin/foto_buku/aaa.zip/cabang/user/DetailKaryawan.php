<div class="row">
  <div class="col-md-12">
    <h1 class="page-header">
            Detail Karyawan <small>Standart American</small>
    </h1>
</div>
     
      <div class="row">
                <div class="col-md-4 col-sm-4">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <i class="fa fa-user"></i> Karyawan
                        </div>
                        <div class="panel-body">
                         <img src="../../image/cct.jpg" alt="AAAAA" class="img-thumbnail" >
                        </div>
                        <div class="panel-footer">
                            Panel Footer
                        </div>
                    </div>
                </div>