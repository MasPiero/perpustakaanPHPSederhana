<?php
include "../../koneksi.php";
$nik = $_GET['nik'];
  $query = mysql_query("SELECT * FROM tbkaryawan WHERE nik='$nik'");
  while($data = mysql_fetch_array($query)){
  ?>
          
            <div class="panel panel-defautl">
              <div class="panel-heading">
                <h3 class="panel-title"><i class="fa fa-user"></i> Edit Data Karyawan </h3>
              </div>
              <div class="panel-body">
                 <div class="table-responsive">
                  
    <form action="ProsesEditKaryawan.php" method="post">
    <table class="table table-condensed">
    
      <tr>
        <td><label for="">Kode Karyawan</label></td>
        <td><input name="nik" type="text" readonly class="form-control" value="<?php echo $data ['nik']?>" ></td>
      </tr>
      <tr>
        <td><label for="">Nama Karyawan</label></td>
        <td><input name="nama_karyawan" type="text" class="form-control" value="<?php echo $data ['nama']?>"></td>
      </tr>
      <tr>
        <td><label for="">Tempat Lahir</label></td>
        <td><input name="tempat_lahir" type="text" class="form-control" value="<?php echo $data ['tempat_lahir']?>"> </td>
      </tr>
      <tr>
        <td><label for="">Tanggal Lahir</label></td>
        <td><input name="tanggal_lahir" type="date" class="form-control" value="<?php echo $data ['tanggal_lahir']?>"</td>
      </tr>
      <tr>
        <td><label for="">Department</label></td>
        <td><input name="departement" type="text" class="form-control" value="<?php echo $data ['departement']?>"</td>
      </tr>
      <tr>
        <td><input type="submit" value="Update Data"  name="update" class="btn btn-sm btn-primary"/>&nbsp;<a href="beranda.php?hal=DataKaryawan" class="btn btn-sm btn-primary">Kembali</a></td>
        </tr>
    </table>
    </form>
    <?php
    }
      ?>
                   </div>
                
              </div> 
            </div>
          </div>
        </div><!-- /.row --> 
      </div><!-- /#page-wrapper -->

    </div><!-- /#wrapper -->

    <!-- JavaScript -->
    <script src="js/jquery-1.10.2.js"></script>
    <script src="js/bootstrap.js"></script>

    <!-- Page Specific Plugins -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="http://cdn.oesmith.co.uk/morris-0.4.3.min.js"></script>
    <script src="js/morris/chart-data-morris.js"></script>
    <script src="js/tablesorter/jquery.tablesorter.js"></script>
    <script src="js/tablesorter/tables.js"></script>

 