<?php
include "../../koneksi.php";
session_start();

$r	=	mysql_fetch_array(mysql_query("SELECT * FROM tbadmin where kode_admin='$_SESSION[kode_admin]'"));

$pass_lama	=	$_POST['pass_lama'];
$pass_baru	=	$_POST['pass_baru'];

if (empty($_POST['pass_baru']) OR empty($_POST['pass_lama']) OR empty($_POST['konfirmasi'])){
	  echo "<p align=center>Anda harus mengisikan semua data pada form Ganti Password.<br />"; 
	  echo "<a href=javascript:history.go(-1)><b>Ulangi Lagi</b></a></p>";
}
else{ 
	// Apabila password lama cocok dengan password admin di database
	if ($pass_lama==$r['pass_admin']){
	  // Pastikan bahwa password baru yang dimasukkan sebanyak dua kali sudah cocok
		if ($_POST['pass_baru']==$_POST['konfirmasi']){
			mysql_query("UPDATE tbadmin SET pass_admin = '$pass_baru'");
			echo "<script>alert('Ganti Password Berhasil'); window.location = 'logout_mimin.php'</script>";
		}
		else{
			echo "<script>alert('Password baru yang anda masukkan tidak sama'); window.location = 'Beranda.php?hal=Pengaturan'</script>";
		}
	}
	else{
		echo "<script>alert('Password Lama anda salah'); window.location = 'Beranda.php?hal=Pengaturan'</script>";
	}
}
?>
