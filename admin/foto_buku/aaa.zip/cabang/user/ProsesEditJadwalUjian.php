<?php
include "../../koneksi.php";
	
	$no_ujian= $_POST['no_ujian'];
	$tanggal_ujian	= $_POST['tanggal_ujian'];
	$ruang			= $_POST['ruang'];
	$jam_mulai		= $_POST['jam_mulai'];
	$jam_akhir		= $_POST['jam_akhir'];
	$kode_jadwal	= $_POST['kode_jadwal'];
	




$edit = mysql_query("UPDATE ujian SET tanggal_ujian='$tanggal_ujian', ruang='$ruang', jam_mulai='$jam_mulai', jam_akhir='$jam_akhir', kode_jadwal='$kode_jadwal' WHERE no_ujian='$no_ujian' ");

echo "<script>alert('Data Telah Berhasil diubah!!!');
window.location='beranda.php?hal=JadwalUjian','_blank';</script>";


?>