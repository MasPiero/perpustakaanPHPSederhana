<div class="row">
  <div class="col-md-12">
    <h1 class="page-header">
            Tambah Jadwal Pelatihan <small>American Standard</small>
    </h1>
</div>

<div class="col-lg-12">
            <div class="panel panel-default">
              <div class="panel-heading">
                <h3 class="panel-title"><i class="fa fa-calendar"></i> Tambah Jadwal Pelatihan </h3>
              </div>
              <div class="panel-body">
                 <div class="table-responsive">
                  
    <form action="ProsesTambahJadwalPelatihan.php" method="post">
    <table class="table table-condensed">
   
      <tr>
        <td><label for="">Kode Jadwal</label></td>
        <td><input name="kode_jadwal" type="text" class="form-control" id="kode_jadwal" placeholder="Kode Jadwal" required/></td>
      </tr>
      <tr>
        <td><label for="">Tanggal Pelatihan</label></td>
        <td><input name="tanggal_pelatihan" type="date" class="form-control" id="tanggal_pelatihan" required/></td>
      </tr>
      <tr>
        <td><label for="">Ruang</label></td>
        <td><input name="ruang" type="text" class="form-control" id="ruang" placeholder="Ruang " required/></td>
      </tr>
      <tr>
        <td><label for="">Jam Mulai</label></td>
        <td><input name="jam_mulai" type="text" class="form-control" id="jam_mulai" placeholder="Jam Mulai" required/></td>
      </tr>
       <tr>
        <td><label for="">Jam Akhir</label></td>
        <td><input name="jam_akhir" type="text" class="form-control" id="jam_akhir" placeholder="Jam Mulai" required/></td>
      </tr>
       <tr>
      <td><label > Jenis Pelatihan</label></td>
                    <td> <?php
                              include "../../koneksi.php";

                            echo "<select class='col-sm-6' name='kode_pelatihan'>";
                            $tampil = mysql_query("SELECT * FROM pelatihan ");
                            
                            while($w=mysql_fetch_array($tampil))
                                  {
                          echo "<option value=$w[kode_pelatihan] selected>$w[jenis_pelatihan]</option>";        
                            }
                             echo "</select>";
                            ?>
      </tr>
       <tr>
      <td><label > Nama Trainer</label></td>
                    <td> <?php
                              include "../../koneksi.php";

                            echo "<select class='col-sm-6' name='kode_trainer'>";
                            $tampil = mysql_query("SELECT * FROM tbtrainer ");
                            
                            while($w=mysql_fetch_array($tampil))
                                  {
                          echo "<option value=$w[kode_trainer] selected>$w[nama_trainer]</option>";        
                            }
                             echo "</select>";
                            ?>
      </tr>      
      <tr>
        <td><input type="submit" value="Simpan Data"  class="btn btn-sm btn-primary"/>&nbsp;<a href="beranda.php?hal=JadwalPelatihan" class="btn btn-sm btn-primary">Kembali</a></td>
        </tr>
    </table>
    </form>
                   </div>
                
              
                </div>
              </div> 
            </div>
          </div>
        </div><!-- /.row --> 