<?php

include "../../koneksi.php";
	$kode_trainer		= $_POST['kode_trainer'];
	$nama_trainer		= $_POST['nama_trainer'];
	$alamat		= $_POST['alamat'];
	$no_telp			= $_POST['no_telp'];
	$email		= $_POST['email'];
	

	$query =mysql_query("INSERT INTO tbtrainer VALUES ('$kode_trainer','$nama_trainer','$alamat','$no_telp','$email')");
	if($query){
		 echo "<script>window.alert('Data Trainer Berhasil Disimpan')</script>";
 		 echo "<meta http-equiv='refresh' content='0; url=beranda.php?hal=DataTrainer'>";
	}
	




?>