<div class="row">
      <div class="col-md-12">
      	<h1 class="page-header">
      		Beranda <small>American Standard</small>
      	</h1>
       </div>
</div>

<div class="row">
                    <div class="col-md-3 col-sm-12 col-xs-12">
                        <div class="panel panel-primary text-center no-boder bg-color-green">
                            <div class="panel-body">
                                <i class="fa fa-users fa-5x"></i>
                                <h3><?php
                                	$sql = "SELECT nama FROM tbkaryawan";
									$query = mysql_query($sql);
									$count = mysql_num_rows($query);
									echo "$count";
                                ?></h3>
                            </div>
                            <div class="panel-footer back-footer-green">
                                Peserta

                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-12 col-xs-12">
                        <div class="panel panel-primary text-center no-boder bg-color-blue">
                            <div class="panel-body">
                                <i class="fa fa-share fa-5x"></i>
                                <h3>
                                	<?php
                                	$sql = "SELECT kode_pelatihan FROM pelatihan";
									$query = mysql_query($sql);
									$count = mysql_num_rows($query);
									echo "$count";
                                ?>
                                </h3>
                            </div>
                            <div class="panel-footer back-footer-blue">
                                Pelatihan

                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-12 col-xs-12">
                        <div class="panel panel-primary text-center no-boder bg-color-red">
                            <div class="panel-body">
                                <i class="fa fa fa-user fa-5x"></i>
                                <h3>
                                	<?php
                                	$sql = "SELECT nama_trainer FROM tbtrainer";
									$query = mysql_query($sql);
									$count = mysql_num_rows($query);
									echo "$count";
                                ?>
                                </h3>
                            </div>
                            <div class="panel-footer back-footer-red">
                                Trainer

                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-12 col-xs-12">
                        <div class="panel panel-primary text-center no-boder bg-color-brown">
                            <div class="panel-body">
                                <i class="fa fa-calendar fa-5x"></i>
                                <h3>
                                <?php
                                	$sql = "SELECT no_ujian FROM ujian";
									$query = mysql_query($sql);
									$count = mysql_num_rows($query);
									echo "$count";
                                ?> </h3>
                            </div>
                            <div class="panel-footer back-footer-brown">
                               Jadwal Ujian

                            </div>
                        </div>
                    </div>
                </div>

                 <div class="row">                     
                      
                               <div class="col-md-6 col-sm-12 col-xs-12">                     
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Jenis Pelatihan
                        </div>
                        <div class="panel-body">
                          <div class="table-responsive">
                            
                                    <?php
                                        $tampil=mysql_query ("SELECT * from pelatihan ");
                                        
                                       
                                    ?>
                                <table class="table table-striped table-bordered table-hover" id="dataTables-exmple">
                                    <thead>
                                        <tr >
                                            <th>Kode Pelatihan</th>
                                            <th>Jenis Pelatihan</th>
                                            <th>golongan</th>
                                           
                                           
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while($data=mysql_fetch_array($tampil))
                                             { ?>
                                            <tr>
                                            <td><?php echo $data['kode_pelatihan']; ?></td>
                                            <td><?php echo $data['jenis_pelatihan']; ?></td>
                                             <td><?php echo $data['golongan_pelatihan']; ?></td>
                                            
                                         </tr>
                                             <?php   
                                          }
                                          ?>
                                      
                                    </tbody>
                                </table>
                            </div> 


                        </div>
                    </div>            
                </div>
                      <div class="col-md-6 col-sm-12 col-xs-12">                     
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Karyawan Terbaik
                        </div>
                        <div class="panel-body">                            
							<div class="panel-body">
                          <div class="table-responsive">
                            
                                    <?php
                                        $tampil2=mysql_query ("SELECT * from detail_jadwal_pelatihan left join tbkaryawan on detail_jadwal_pelatihan.nik = tbkaryawan.nik LEFT JOIN jadwal_pelatihan on detail_jadwal_pelatihan.kode_jadwal = jadwal_pelatihan.kode_jadwal LEFT JOIN pelatihan ON jadwal_pelatihan.kode_pelatihan=pelatihan.kode_pelatihan where skor >= 70 order by skor desc LIMIT 10");
                                       
                                    ?>
                                <table class="table table-striped table-bordered table-hover" id="dataTables-exmple">
                                    <thead>
                                        <tr >
                                            <th>NIK</th>
                                            <th>Nama Karyawan</th>
                                             <th>Jenis Pelatihan</th>
                                            <th>Skor</th>
                                           
                                           
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while($data=mysql_fetch_array($tampil2))
                                             { ?>
                                            <tr>
                                            <td><?php echo $data['nik']; ?></td>
                                            <td><?php echo $data['nama']; ?></td>
                                             <td><?php echo $data['jenis_pelatihan']; ?></td>
                                             <td><?php echo $data['skor']; ?></td>
                                            
                                         </tr>
                                             <?php   
                                          }
                                          ?>
                                      
                                    </tbody>
                                </table>
                            </div> 
</div>
                        </div>
                    </div>            
                </div>  	