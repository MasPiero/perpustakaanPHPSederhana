<div class="row">
  <div class="col-md-12">
    <h1 class="page-header">
            Tambah Pelatihan <small>American Standard</small>
    </h1>
</div>

<div class="col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title"><i class="fa fa-user"></i> Tambah Jadwal Pelatihan </h3>
              </div>
              <div class="panel-body">
                 <div class="table-responsive">
                  
    <form action="ProsesTambahPelatihan.php" method="post">
    <table class="table table-condensed">
   
      <tr>
        <td><label for="">No Pelatihan</label></td>
        <td><input name="no_pelatihan" type="text" class="form-control" id="no_pelatihan" placeholder="No Pelatihan" required/></td>
      </tr>
      <tr>
        <td><label for="">Tanggal Pelatihan</label></td>
        <td><input name="tanggal_pelatihan" type="date" class="form-control" id="tanggal_pelatihan" placeholder="Tanggal Pelatihan" required/></td>
      </tr>
     <tr>
      <td><label > Nama Materi</label></td>
                    <td> <?php
                              include "../koneksi.php";

                            echo "<select class='col-sm-6' name='kode_materi'>";
                            $tampil = mysql_query("SELECT * FROM tbmateri_pelatihan");
                            
                            while($w=mysql_fetch_array($tampil))
                                  {
                          echo "<option value=$w[kode_materi] selected>$w[nama_materi]</option>";        
                            }
                             echo "</select>";
                            ?>
      </tr>
      <tr>
      <td><label > Nama Trainer</label></td>
                    <td> <?php
                              include "../koneksi.php";

                            echo "<select class='col-sm-6' name='kode_trainer'>";
                            $tampil = mysql_query("SELECT * FROM tbtrainer");
                            
                            while($w=mysql_fetch_array($tampil))
                                  {
                          echo "<option value=$w[kode_trainer] selected>$w[nama_trainer]</option>";        
                            }
                             echo "</select>";
                            ?>
      </tr>
      
      
      <tr>
        <td><input type="submit" value="Simpan Data"  class="btn btn-sm btn-primary"/>&nbsp;<a href="beranda.php?hal=JadwalPelatihan" class="btn btn-sm btn-primary">Kembali</a></td>
        </tr>
    </table>
    </form>
                   </div>
                
              
                </div>
              </div> 
            </div>
          </div>
        </div><!-- /.row --> 