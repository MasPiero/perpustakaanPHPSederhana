<?php

include "../../koneksi.php";
	$kode_pelatihan			= $_POST['kode_pelatihan'];
	$jenis_pelatihan		= $_POST['jenis_pelatihan'];
	$materi_pelatihan		= $_POST['materi_pelatihan'];
	$golongan				= $_POST['golongan'];
	

	$query =mysql_query("INSERT INTO pelatihan VALUES ('$kode_pelatihan','$jenis_pelatihan','$materi_pelatihan','$golongan')");
	if($query){
		 echo "<script>window.alert('Data Pelatihan Berhasil Disimpan')</script>";
 		 echo "<meta http-equiv='refresh' content='0; url=beranda.php?hal=JenisPelatihan'>";
	}
	




?>