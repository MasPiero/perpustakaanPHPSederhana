<?php 
include('../../koneksi.php');
$id = $_GET['id_kategori'];
$query = mysql_query("delete from tbkategori_soal where id_kategori='$id'") or die(mysql_error());

 echo "<meta http-equiv='refresh' content='0; url=beranda.php?hal=DataKategoriSoal'>";
?>