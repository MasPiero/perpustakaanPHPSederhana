<div class="row">
  <div class="col-md-12">
    <h1 class="page-header">
            Tambah Soal <small>American Standard</small>
    </h1>
</div>

<div class="col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title"><i class="fa fa-user"></i> Tambah Soal </h3>
              </div>
              <div class="panel-body">
                 <div class="table-responsive">
                  
    <form action="ProsesTambahSoal.php" method="post">
    <table class="table table-condensed">
   
      <tr>
      <td><label > Nama Materi</label></td>
                    <td> <?php
                              include "../koneksi.php";

                            echo "<select class='col-sm-6' id = 'nama-materi' name='nama_materi'>";
                            $tampil = mysql_query("SELECT * FROM tbmateri_pelatihan ");
                            
                            while($w=mysql_fetch_array($tampil))
                                  {
                          echo "<option value='$w[nama_materi]' selected>'$w[nama_materi]'</option>";        
                            }
                             echo "</select>";
                            ?>
      </tr>
     
      <tr>
        <td><label for="">Pertanyaan</label></td>
        <td><input name="pertanyaan" type="text" class="form-control" id="pertanyaan" placeholder="Pertanyaan" required/></td>
      </tr>
      <tr>
        <td><label for="">Jawaban A</label></td>
        <td><input name="jawaban_a" type="text" class="form-control" id="jawaban_a" placeholder=" " required/></td>
      </tr>
      <tr>
        <td><label for="">Jawaban B</label></td>
        <td><input name="jawaban_b" type="text" class="form-control" id="jawaban_b"  required/></td>
      </tr>
      <tr>
        <td><label for="">Jawaban C</label></td>
        <td><input name="jawaban_c" type="text" class="form-control" id="jawaban_c" placeholder="" required/></td>
      </tr>
      <tr>
        <td><label for="">Jawaban D</label></td>
        <td><input name="jawaban_d" type="text" class="form-control" id="jawaban_d" placeholder="" required/></td>
      </tr>
      <tr>
        <td><label for="">Jawaban Benar</label></td>
        <td><input name="jawaban" type="text" class="form-control" id="jawaban" placeholder="" required/></td>
      </tr>
      
      <tr>
        <td><input type="submit" value="Simpan Soal"  class="btn btn-sm btn-primary"/>&nbsp;<a href="beranda.php?hal=DataSoal" class="btn btn-sm btn-primary">Kembali</a></td>
        </tr>
    </table>
    </form>
                   </div>
                
              
                </div>
              </div> 
            </div>
          </div>
        </div><!-- /.row --> 