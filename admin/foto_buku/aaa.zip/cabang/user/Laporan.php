<div class="row">
    <div class="col-md-12">
    <h1 class="page-header">
            Laporan <small>American Standard</small>
    </h1>
    </div>

<div class="col-lg-6">
            <div class="panel panel-primary">
               <div class="panel-heading">
                <h3 class="panel-title"><i class="fa fa-file"></i> Laporan Pelatihan </h3>
               </div>
               <div class="panel-body">
               <div class="table-responsive">
                  
    <form action="Laporan_Pelatihan.php" method="post">
    <table class="table table-condensed">
   
      <tr>
        <td><label for="">Tanggal Awal</label></td>
        <td><input name="tanggal_awal" type="date" class="form-control" id="tanggal_awal" placeholder="No Pelatihan" required/></td>
      </tr>
      <tr>
        <td><label for="">Tanggal Akhir</label></td>
        <td><input name="tanggal_akhir" type="date" class="form-control" id="tanggal_akhir" placeholder="Tanggal Pelatihan" required/></td>
      </tr>
     
      
      
      <tr>
        <td><input type="submit" value="Cetak"  class="btn btn-sm btn-primary" />&nbsp;<a href="beranda.php?hal=JadwalPelatihan" class="btn btn-sm btn-primary">Kembali</a></td>
        </tr>
    </table>
    </form>
                   </div>

                </div>
              </div>

            </div>
            <div class="col-lg-6">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title"><i class="fa fa-file"></i> Laporan Jadwal Ujian </h3>
              </div>
              <div class="panel-body">
                 <div class="table-responsive">
                  
    <form action="LaporanUjian.php" method="post">
    <table class="table table-condensed">
   
      <tr>
        <td><label for="">Tanggal Awal</label></td>
        <td><input name="tanggal_awal" type="date" class="form-control" id="tanggal_awal" placeholder="No Pelatihan" required/></td>
      </tr>
      <tr>
        <td><label for="">Tanggal Akhir</label></td>
        <td><input name="tanggal_akhir" type="date" class="form-control" id="tanggal_akhir" placeholder="Tanggal Pelatihan" required/></td>
      </tr>
     
      
      
      <tr>
        <td><input type="submit" value="Simpan Data"  class="btn btn-sm btn-primary"/>&nbsp;<a href="beranda.php?hal=JadwalPelatihan" class="btn btn-sm btn-primary">Kembali</a></td>
        </tr>
    </table>
    </form>
                   </div>

          </div>

</div>

        </div>



    

<div class="col-lg-6">
            <div class="panel panel-primary">
               <div class="panel-heading">
                <h3 class="panel-title"><i class="fa fa-user"></i> Laporan Karyawan </h3>
               </div>
               <div class="panel-body">
               <div class="table-responsive">
                  
    <form action="Laporan_Pelatihan.php" method="post">
    <table class="table table-condensed">
   
      <tr>
        <td><label for="">Cetak laporan Karyawan</label></td>
       <td><label for="">Cetak laporan Trainer</label></td>
      </tr>
      
      
      
      <tr>
        <td><a href="CetakLaporanKaryawan.php" class="btn btn-sm btn-primary">Cetak</a></td>
        <td><a href="CetakLaporanTrainer.php" class="btn btn-sm btn-primary">Cetak</a></td>
        </tr>
    </table>
    </form>
                   </div>

                </div>
              </div>

