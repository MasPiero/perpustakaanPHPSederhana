<?php

include "../../koneksi.php";
	
	$nama_materi			= $_POST['nama_materi'];
	$pertanyaan				= $_POST['pertanyaan'];
	$jawaban_a				= $_POST['jawaban_a'];
	$jawaban_b				= $_POST['jawaban_b'];
	$jawaban_c				= $_POST['jawaban_c'];
	$jawaban_d				= $_POST['jawaban_d'];
	$jawaban				= $_POST['jawaban'];

	

	$query =mysql_query("INSERT INTO tbsoal VALUES ('','$nama_materi','$pertanyaan','$jawaban_a','$jawaban_b','$jawaban_c','$jawaban_d','$jawaban')");
	if($query){
		 echo "<script>window.alert('Data Soal Berhasil Disimpan')</script>";
 		 echo "<meta http-equiv='refresh' content='0; url=beranda.php?hal=DataSoal'>";
	}
	




?>