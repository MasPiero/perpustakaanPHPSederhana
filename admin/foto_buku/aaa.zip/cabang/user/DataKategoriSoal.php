<?php
include "../../koneksi.php";
?>


 <div class="row">
      <div class="col-md-12">
        <h1 class="page-header">
            Data Kategori Soal <small>American Standard</small>
        </h1>
       </div>
</div>

            <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                        Data Kategori Soal
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                            <div class="text-left">
                            <a href="?hal=TambahKategoriSoal" class="btn btn-sm btn-primary">Tambah Kategori Soal <i class="fa fa-arrow-circle-right"></i></a>
                            <br><br>
              
                                    <?php
                                        $tampil=mysql_query ("select * from tbkategori_soal LEFT JOIN tbmateri_pelatihan on tbkategori_soal.kode_materi = tbmateri_pelatihan.kode_materi ");
                                    ?>
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr >
                                            <th hidden>Id Kategori</th>
                                            <th>Nama Materi</th>
                                            <th>Jumlah Soal</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while($data=mysql_fetch_array($tampil))
                                             { ?>
                                            <tr>
                                            <td hidden><?php echo $data['id_kategori']; ?></td>
                                            <td><?php echo $data['nama_materi']; ?></td>
                                             <td><?php echo $data['jumlah_soal'];?></td>
                                           
                                          <td>
                                                <a class="btn btn-sm btn-danger" href="HapusKategori.php?id_kategori=<?php echo $data['id_kategori'];?>"><i class="fa fa-wrench"></i> Hapus</a></td></tr>
                                             <?php   
                                          }
                                          ?>
                                      
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>
                <!-- /. ROW  -->
            
                <!-- /. ROW  -->
            
                <!-- /. ROW  -->
            
                <!-- /. ROW  -->
        </div>
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
  
    
   

