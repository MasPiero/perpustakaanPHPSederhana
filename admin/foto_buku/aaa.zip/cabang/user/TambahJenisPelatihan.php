<div class="row">
  <div class="col-md-12">
    <h1 class="page-header">
            Tambah Jenis Pelatihan <small>American Standard</small>
    </h1>
</div>

<div class="col-lg-12">
            <div class="panel panel-default">
              <div class="panel-heading">
                <h3 class="panel-title"><i class="fa fa-user"></i> Tambah Jenis Pelatihan </h3>
              </div>
              <div class="panel-body">
                 <div class="table-responsive">
                  
    <form action="ProsesTambahJenisPelatihan.php" method="post">
    <table class="table table-condensed">
   
      <tr>
        <td><label for="">Kode Pelatihan</label></td>
        <td><input name="kode_pelatihan" type="text" class="form-control" id="kode_pelatihan" placeholder="Kode Pelatihan Pelatihan" required/></td>
      </tr>
      <tr>
        <td><label for="">Jenis Pelatihan</label></td>
        <td><input name="jenis_pelatihan" type="text" class="form-control" id="jenis_pelatihan" placeholder="Jenis Pelatihan" required/></td>
      </tr>
      <tr>
        <td><label for="">Materi Pelatihan</label></td>
        <td><input name="materi_pelatihan" type="text" class="form-control" id="jenis_pelatihan" placeholder="Materi Pelatihan" required/></td>
      </tr>
      <tr>
        <td><label for="">Golongan Pelatihan</label></td>
        <td><input name="golongan" type="text" class="form-control" id="golongan" placeholder="Deskripsi" required/></td>
      </tr>
            
      <tr>
        <td><input type="submit" value="Simpan Data"  class="btn btn-sm btn-primary"/>&nbsp;<a href="beranda.php?hal=JenisPelatihan" class="btn btn-sm btn-primary">Kembali</a></td>
        </tr>
    </table>
    </form>
                   </div>
                
              
                </div>
              </div> 
            </div>
          </div>
        </div><!-- /.row --> 