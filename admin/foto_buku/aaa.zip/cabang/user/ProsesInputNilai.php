<?php
include "../../koneksi.php";




	$kode_jadwal	= $_POST['kode_jadwal'];
	$id_jadwal	= $_POST['id_jadwal'];
	$jumlah_soal	= $_POST['jumlah_soal'];
	$jawaban_benar	= $_POST['jawaban_benar'];
	$jawaban_salah		= $_POST['jawaban_salah'];
	$jawaban_kosong	= $_POST['jawaban_kosong'];
	$skor	= ($jawaban_benar / $jumlah_soal) * 100;
	
	if ($skor >=80){
		$grade = 'A';
	}
	elseif ($skor >=70 ) {
		$grade = 'B';
	}
	else {
		$grade = 'C';
	}





$edit = mysql_query("UPDATE detail_jadwal_pelatihan SET jumlah_soal='$jumlah_soal', jawaban_benar='$jawaban_benar', jawaban_salah='$jawaban_salah', jawaban_kosong='$jawaban_kosong', skor='$skor' , grade='$grade', keterangan = 'Sudah dinilai' WHERE id_jadwal='$id_jadwal' ");

echo "<script>alert('Data Telah Berhasil diubah!!!');
window.location='beranda.php?hal=PesertaUjian&kode_jadwal=$kode_jadwal'</script>";


?>