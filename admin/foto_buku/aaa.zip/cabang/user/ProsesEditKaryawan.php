<?php
include "../../koneksi.php";
	
	$nik			= $_POST['nik'];
	$nama_karyawan	= $_POST['nama_karyawan'];
	$tempat_lahir	= $_POST['tempat_lahir'];
	$tanggal_lahir	= $_POST['tanggal_lahir'];
	$departement	= $_POST['departement'];




$edit = mysql_query("UPDATE tbkaryawan SET nama_karyawan='$nama_karyawan', tempat_lahir='$tempat_lahir', tanggal_lahir='$tanggal_lahir' WHERE nik='$nik' ");

echo "<script>alert('Data Telah Berhasil diubah!!!');
window.location='beranda.php?hal=DataKaryawan','_blank';</script>";


?>