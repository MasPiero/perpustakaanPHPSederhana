<?php
include "../../koneksi.php";
	
	$kode_trainer	= $_POST['kode_trainer'];
	$nama_trainer	= $_POST['nama_trainer'];
	$alamat	= $_POST['alamat'];
	$no_telp		= $_POST['no_telp'];
	$email	= $_POST['email'];




$edit = mysql_query("UPDATE tbtrainer SET nama_trainer='$nama_trainer', alamat='$alamat', no_telp='$no_telp', email='$email' WHERE kode_trainer='$kode_trainer' ");

echo "<script>alert('Data Telah Berhasil diubah!!!');
window.location='beranda.php?hal=DataTrainer','_blank';</script>";


?>