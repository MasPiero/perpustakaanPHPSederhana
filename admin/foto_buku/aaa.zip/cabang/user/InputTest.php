<?php
include "../../koneksi.php";
$id_jadwal = $_GET['id_jadwal'];
$query = mysql_query("SELECT * FROM detail_jadwal_pelatihan LEFT JOIN tbkaryawan on detail_jadwal_pelatihan.nik = tbkaryawan.nik WHERE detail_jadwal_pelatihan.id_jadwal='$id_jadwal'");
while($data = mysql_fetch_array($query)){
  ?>
          
            <div class="panel panel-defautl">
              <div class="panel-heading">
                <h3 class="panel-title"><i class="fa fa-user"></i> Input Nilai   [<?php echo $data['nama'] ?>]</h3>
              </div>
              <div class="panel-body">
                 <div class="table-responsive">
                  
    <form action="ProsesInputNilai.php" method="post">
    <table class="table table-condensed">
    
      <tr hidden>
        <td><label for="">id Jadwal</label></td>
        <td><input name="id_jadwal" readonly type="text" readonly class="form-control" value="<?php echo $data ['id_jadwal']?>" ></td>
      </tr>
      <tr>
        <td><label for="">Kode jadwal</label></td>
        <td><input name="kode_jadwal" readonly type="text" class="form-control" value="<?php echo $data ['kode_jadwal']?>"></td>
      </tr>
      <tr>
        <td><label for="">NIK</label></td>
         <td><input name="nik" readonly type="text" class="form-control" rows="5"  value="<?php echo $data ['nik']?>"></td>
       </tr>
       <tr>
        <td><label for="">Nama Karyawan</label></td>
         <td><input name="nama" readonly type="text" class="form-control" required rows="5"  value="<?php echo $data ['nama']?>"></td>
       </tr>
       <tr>
        <td><label for="">Jumlah Soal</label></td>
         <td><input name="jumlah_soal"  type="number" class="form-control" required value="<?php echo $data ['jumlah_soal']?>"></td>
       </tr>
       <tr>
        <td><label for="">Jawaban Benar</label></td>
         <td><input name="jawaban_benar"  type="number" class="form-control" required  value="<?php echo $data ['jawaban_benar']?>"></td>
       </tr>
        <tr>
        <td><label for="">Jawaban Salah</label></td>
         <td><input name="jawaban_salah"  type="number" class="form-control" required  value="<?php echo $data ['jawaban_salah']?>"></td>
       </tr>
       <tr>
        <td><label for="">Jawaban Kosong</label></td>
         <td><input name="jawaban_kosong"  type="number" class="form-control" required  value="<?php echo $data ['jawaban_kosong']?>"></td>
       </tr>
       <tr>
        <td><label for="">Skor</label></td>
         <td><input name="skor"  type="number" readonly class="form-control" required  value="<?php echo $data ['skor']?>"></td>
       </tr>
        <tr>
        <td><label for="">Grade</label></td>
         <td><input name="grade"  type="text" readonly class="form-control" required  value="<?php echo $data ['grade']?>"></td>
       </tr>
      <tr>
        <td><input type="submit" value="Input Nilai"  name="update" class="btn btn-sm btn-primary"/>&nbsp;<a href="beranda.php?hal=PesertaUjian&kode_jadwal=<?php echo $data['kode_jadwal'] ?>" class="btn btn-sm btn-primary">Kembali</a></td>
        </tr>
    </table>
    </form>
    <?php
    }
      ?>
                   </div>
                
              </div> 
            </div>
          </div>
        </div><!-- /.row --> 
      </div><!-- /#page-wrapper -->

    </div><!-- /#wrapper -->

    <!-- JavaScript -->
    <script src="js/jquery-1.10.2.js"></script>
    <script src="js/bootstrap.js"></script>

    <!-- Page Specific Plugins -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="http://cdn.oesmith.co.uk/morris-0.4.3.min.js"></script>
    <script src="js/morris/chart-data-morris.js"></script>
    <script src="js/tablesorter/jquery.tablesorter.js"></script>
    <script src="js/tablesorter/tables.js"></script>

 