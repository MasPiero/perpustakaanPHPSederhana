<?php
include "../../koneksi.php";

if($_GET) {
    # Baca variabel URL
    $kode_jadwal = mysql_real_escape_string($_GET['kode_jadwal']);
    
    # Perintah untuk mendapatkan data dari tabel penjualan
    $mySql = "select * from detail_jadwal_pelatihan LEFT JOIN tbkaryawan on detail_jadwal_pelatihan.nik = tbkaryawan.nik  where detail_jadwal_pelatihan.kode_jadwal = '$kode_jadwal'";
    $myQry = mysql_query($mySql)  or die ("Query salah : ".mysql_error());
  
    
}
else {
    echo "No Pelatihan Tidak Terbaca";
    exit;

    
}
?>


<div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                        Data Peserta Pelatihan 
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                            <div class="text-left">
                            
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr >
                                           
                                            <th>NIK</th>
                                            <th>Nama Karyawan</th>
                                            <th>Departement</th>
                                           
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while($data=mysql_fetch_array($myQry))
                                             { ?>
                                            <tr>
                                            
                                            <td><?php echo $data['nik']; ?></td>
                                             <td><?php echo $data['nama']; ?></td>
                                            <td><?php echo $data['departement']; ?></td>
                                           
                                          
                                             <?php   
                                          }
                                          ?>
                                      
                                    </tbody>
                                </table>
                                <a class="btn btn-sm btn-primary" href="beranda.php?hal=JadwalPelatihan"><i class="fa fa-sort"></i> Kembali</a></td></tr>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>

 