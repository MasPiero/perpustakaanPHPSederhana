<?php
include "../../koneksi.php";
	
	$kode_pelatihan	= $_POST['kode_pelatihan'];
	$jenis_pelatihan	= $_POST['jenis_pelatihan'];
	$materi_pelatihan		= $_POST['materi_pelatihan'];
	$golongan		= $_POST['golongan'];
	




$edit = mysql_query("UPDATE pelatihan SET jenis_pelatihan='$jenis_pelatihan', materi_pelatihan='$materi_pelatihan', golongan_pelatihan='$golongan' WHERE kode_pelatihan='$kode_pelatihan' ");

echo "<script>alert('Data Telah Berhasil diubah!!!');
window.location='beranda.php?hal=JenisPelatihan','_blank';</script>";


?>