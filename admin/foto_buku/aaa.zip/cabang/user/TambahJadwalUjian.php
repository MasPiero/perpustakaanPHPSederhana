<div class="row">
  <div class="col-md-12">
    <h1 class="page-header">
            Tambah Jadwal Ujian <small>American Standard</small>
    </h1>
</div>

<div class="col-lg-12">
            <div class="panel panel-default">
              <div class="panel-heading">
                <h3 class="panel-title"><i class="fa fa-user"></i> Tambah Jadwal Ujian </h3>
              </div>
              <div class="panel-body">
                 <div class="table-responsive">
                  
    <form action="ProsesTambahJadwalUjian.php" method="post">
    <table class="table table-condensed">
   
      <tr>
        <td><label for="">No Ujian</label></td>
        <td><input name="no_ujian" type="text" class="form-control" id="no_ujian" placeholder="No Ujian" required/></td>
      </tr>
      <tr>
        <td><label for="">Tanggal Ujian</label></td>
        <td><input name="tanggal_ujian" type="date" class="form-control" id="tanggal_ujian" required=""></td>
      </tr>
      <tr>
        <td><label for="">Ruang</label></td>
        <td><input name="ruang" type="text" class="form-control" id="ruang" placeholder="Ruang Ujian" required/></td>
      </tr>
      <tr>
        <td><label for="">Jam Mulai</label></td>
        <td><input name="jam_mulai" type="text" class="form-control" id="jam_mulai" placeholder="Jam Mulai" required/></td>
      </tr>
      <tr>
        <td><label for="">Jam Akhir</label></td>
        <td><input name="jam_akhir" type="text" class="form-control" id="jam_akhir" placeholder="Jam Akhir" required/></td>
      </tr>
       <tr>
      <td><label > Kode Jadwal</label></td>
                    <td> <?php
                              include "../../koneksi.php";

                            echo "<select class='col-sm-6' name='kode_jadwal'>";
                            $tampil = mysql_query("SELECT * FROM jadwal_pelatihan ");
                            
                            while($w=mysql_fetch_array($tampil))
                                  {
                          echo "<option value=$w[kode_jadwal] selected>$w[kode_jadwal]</option>";        
                            }
                             echo "</select>";
                            ?>
      </tr>
            
      <tr>
        <td><input type="submit" value="Simpan Data"  class="btn btn-sm btn-primary"/>&nbsp;<a href="beranda.php?hal=JadwalUjian" class="btn btn-sm btn-primary">Kembali</a></td>
        </tr>
    </table>
    </form>
                   </div>
                
              
                </div>
              </div> 
            </div>
          </div>
        </div><!-- /.row --> 