<div class="row">
  <div class="col-md-12">
    <h1 class="page-header">
            Tambah Karyawan <small>Standart American</small>
    </h1>
</div>

<div class="col-lg-12">
            <div class="panel panel-default">
              <div class="panel-heading">
                <h3 class="panel-title"><i class="fa fa-user"></i> Tambah Data Karyawan </h3>
              </div>
              <div class="panel-body">
                 <div class="table-responsive">
                  
    <form action="ProsesTambahKaryawan.php" method="post">
    <table class="table table-condensed">
   
      <tr>
        <td><label for="">NIK</label></td>
        <td><input name="nik" type="text" class="form-control" id="nik" placeholder="NIK Karyawan" required/></td>
      </tr>
      <tr>
        <td><label for="">Nama Karyawan</label></td>
        <td><input name="nama_karyawan" type="text" class="form-control" id="nama_karyawan" placeholder="Nama Karyawan" required/></td>
      </tr>
      <tr>
        <td><label for="">Tempat Lahir</label></td>
        <td><input name="tempat_lahir" type="text" class="form-control" id="tempat_lahir" placeholder="Tempat lahir Karyawan" required/></td>
      </tr>
      <tr>
        <td><label for="no_rek">Tanggal Lahir</label></td>
        <td><input name="tanggal_lahir" type="date" class="form-control" id="tanggal_lahir"  required/></td>
      </tr>
      <tr>
        <td><label for="">Departement</label></td>
        <td><input name="departement" type="text" class="form-control" id="departement" placeholder="Departement" required/></td>
      </tr>
      
      <tr>
        <td><input type="submit" value="Simpan Data"  class="btn btn-sm btn-primary"/>&nbsp;<a href="beranda.php?hal=DataKaryawan" class="btn btn-sm btn-primary">Kembali</a></td>
        </tr>
    </table>
    </form>
                   </div>
                
              
                </div>
              </div> 
            </div>
          </div>
        </div><!-- /.row --> 