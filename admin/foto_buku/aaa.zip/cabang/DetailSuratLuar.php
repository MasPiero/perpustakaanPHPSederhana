<?php
include "../koneksi.php";
$id = $_GET['id_suratluar'];
$query = mysqli_query($link,"SELECT * FROM tbsuratluar LEFT JOIN tbkpp on tbsuratluar.kode_kpp = tbkpp.kode_kpp LEFT JOIN tbbagian on tbsuratluar.kode_bagian=tbbagian.kode_bagian LEFT JOIN tbgolongan on tbsuratluar.id_golongan=tbgolongan.id_golongan where tbsuratluar.id_suratluar = '$id'");
while($data = mysqli_fetch_array($query)){
  ?>



<div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="row">
                <div class="col-lg-8">
                  <div class="well bs-component">
                    <form action = "" class="form-horizontal" method="post" enctype="multipart/form-data">
                     
                        <legend>Detail Surat Luar Kota [<?php echo $_SESSION['nama_kpp'] ?>]</legend>
                        <div class="form-group" hidden>
                          <label class="col-lg-3 control-label" for="">id</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "kode_bagian" id="" type="text" value = "<?php echo $data['id'];  ?>"
                          </div>
                       	 </div>
                        
                        </div>
                        <div class="form-group">
                          <label class="col-lg-3 control-label" for="">No Resi</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "nama_bagian" id="" readonly type="text" value = "<?php echo $data['no_resi'];   ?>" 
                          </div>
                       	 </div>
                        
                        </div>

                         

                            <div class="form-group">
                          <label class="col-lg-3 control-label" for="">Seksi / Bagian</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "nama_bagian" id="" readonly type="text" value = "<?php echo $data['nama_bagian'];   ?>" 
                          </div>
                         </div>
                        
                        </div>

                          <div class="form-group">
                          <label class="col-lg-3 control-label" for="">No Surat</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "nama_bagian" id="" readonly type="text" value = "<?php echo $data['no_surat'];   ?>" 
                          </div>
                         </div>
                        
                        </div>
                          <div class="form-group">
                          <label class="col-lg-3 control-label" for="">Tanggal Masuk</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "nama_bagian" id="" readonly type="text" value = "<?php echo $data['tgl_masuk'];   ?>" 
                          </div>
                         </div>
                        
                        </div>
                         
                          <div class="form-group">
                          <label class="col-lg-3 control-label" for="">Golongan</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "nama_bagian" id="" readonly type="text" value = "<?php echo $data['nama_golongan'];   ?>" 
                          </div>
                         </div>
                        
                        </div>
                          <div class="form-group">
                          <label class="col-lg-3 control-label" for="">Qty</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "nama_bagian" id="" readonly type="text" value = "<?php echo $data['qty'];   ?>" 
                          </div>
                         </div>
                        
                        </div>
                          <div class="form-group">
                          <label class="col-lg-3 control-label" for="">Harga</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "nama_bagian" id="" readonly type="text" value = "<?php echo $data['harga'];   ?>" 
                          </div>
                         </div>
                        
                       
                        
                        </div>
                          <div class="form-group">
                          <label class="col-lg-3 control-label" for="">Tujuan Nama</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "nama_bagian" id="" readonly type="text" value = "<?php echo $data['tujuan_nama'];   ?>" 
                          </div>
                         </div>

                              </div>
                          <div class="form-group">
                          <label class="col-lg-3 control-label" for="">Nama Penerima</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "nama_bagian" id="" readonly type="text" value = "<?php echo $data['penerima'];   ?>" 
                          </div>
                         </div>
                        
                        </div>
                          <div class="form-group">
                          <label class="col-lg-3 control-label" for="">Tujuan Jalan</label>
                          <div class="col-lg-9">
                            <input class="form-control" name = "tujuan_jalan" id="" readonly type="text" value = "<?php echo $data['tujuan_jalan'];   ?>" 
                          </div>
                         </div>
                        
                        </div>
                        <div class="form-group">
                          <div class="col-lg-8 col-lg-offset-3">
                         	 
                             <a class="btn btn-primary" href="beranda.php?hal=DataSuratLuar"> <i class="fa fa-arrow-left">Kembali</i></a>
                            
                          </div>
                        
                    </div>

                  </form>
                 <?php

             }
             ?>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>