
<div class="row">
      <div class="col-md-12">
      	<h1 class="page-header">
      		Beranda <small><?php  echo $_SESSION['nama_kpp']  ?></small>
      	</h1>
       </div>
</div>

<div class="row">
                    <div class="col-md-3 col-sm-12 col-xs-12">
                        <div class="panel panel-primary text-center no-boder bg-color-green">
                            <div class="panel-body">
                                <i class="fa fa-users fa-5x"></i>
                                <h3><?php
                                	$sql = "SELECT kode_kpp FROM tbsuratdalam where kode_kpp = '$_SESSION[kode_kpp]' ";
									$query = mysqli_query($link,$sql);
									$count = mysqli_num_rows($query);
									echo "$count";
                                ?></h3>
                            </div>
                            <div class="panel-footer back-footer-green">
                                Surat Dalam Kota

                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-12 col-xs-12">
                        <div class="panel panel-primary text-center no-boder bg-color-blue">
                            <div class="panel-body">
                                <i class="fa fa-share fa-5x"></i>
                                <h3>
                                	<?php
                                	$sql = "SELECT kode_kpp FROM tbsuratluar where kode_kpp = '$_SESSION[kode_kpp]' ";
									$query = mysqli_query($link,$sql);
									$count = mysqli_num_rows($query);
									echo "$count";
                                ?>
                                </h3>
                            </div>
                            <div class="panel-footer back-footer-blue">
                               Surat Luar Kota

                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-12 col-xs-12">
                        <div class="panel panel-primary text-center no-boder bg-color-red">
                            <div class="panel-body">
                                <i class="fa fa fa-user fa-5x"></i>
                                <h3>
                                	<?php
                                	$sql = "SELECT kode_kpp FROM tbsuratdalam where kode_kpp = '$_SESSION[kode_kpp]' ";
									$query = mysqli_query($link,$sql);
									$count = mysqli_num_rows($query);
									echo "$count";
                                ?>
                                </h3>
                            </div>
                            <div class="panel-footer back-footer-red">
                                Terkirim

                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-12 col-xs-12">
                        <div class="panel panel-primary text-center no-boder bg-color-brown">
                            <div class="panel-body">
                                <i class="fa fa-calendar fa-5x"></i>
                                <h3>
                                <?php
                                	$sql = "SELECT kode_kpp FROM tbsuratdalam where kode_kpp = '$_SESSION[kode_kpp]' ";
							 		$query = mysqli_query($link,$sql);
									$count = mysqli_num_rows($query);
									echo "$count";
                                ?> </h3>
                            </div>
                            <div class="panel-footer back-footer-brown">
                               On Proses

                            </div>
                        </div>
                    </div>
                    <br><br><br><br>  <br><br><br><br>  <br><br><br><br>  <br><br><br><br>  <br><br><br><br>  <br><br><br><br>
                     <br><br><br><br>  <br><br><br><br>  <br><br><br><br>  <br><br><br><br>  <br><br><br><br>  <br><br><br><br>
                 
</div>