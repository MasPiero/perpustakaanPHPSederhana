<?php
include "../koneksi.php";
session_start();

$r	=	mysqli_fetch_array(mysqli_query($link,"SELECT * FROM tbkpp where kode_kpp='$_SESSION[kode_kpp]'"));

$pass_lama	=	$_POST['pass_lama'];
$pass_baru	=	$_POST['pass_baru'];

if (empty($_POST['pass_baru']) OR empty($_POST['pass_lama']) OR empty($_POST['konfirmasi'])){
	  echo "<p align=center>Anda harus mengisikan semua data pada form Ganti Password.<br />"; 
	  echo "<a href=javascript:history.go(-1)><b>Ulangi Lagi</b></a></p>";
}
else{ 
	// Apabila password lama cocok dengan password admin di database
	if ($pass_lama==$r['password']){
	  // Pastikan bahwa password baru yang dimasukkan sebanyak dua kali sudah cocok
		if ($_POST['pass_baru']==$_POST['konfirmasi']){
			mysqli_query($link,"UPDATE tbkpp SET password = '$pass_baru' where kode_kpp = '$_SESSION[kode_kpp]'");
			echo "<script>alert('Ganti Password Berhasil'); window.location = '../logout.php'</script>";
		}
		else{
			echo "<script>alert('Password baru yang anda masukkan tidak sama'); window.location = 'Beranda.php?hal=Pengaturan'</script>";
		}
	}
	else{
		echo "<script>alert('Password Lama anda salah'); window.location = 'Beranda.php?hal=Pengaturan'</script>";
	}
}
?>
