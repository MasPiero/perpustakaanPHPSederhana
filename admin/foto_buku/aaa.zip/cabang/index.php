<?php
header('location:beranda.php?hal=Depan');
?>