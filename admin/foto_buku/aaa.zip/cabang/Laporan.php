<div class="row">
    <div class="col-md-12">
    <h1 class="page-header">
            Laporan <small><?php echo $_SESSION['nama_kpp'] ?></small>
    </h1>
    </div>

<div class="col-lg-6">
            <div class="panel panel-primary">
               <div class="panel-heading">
                <h3 class="panel-title"><i class="fa fa-file"></i> Laporan Surat Dalam Kota </h3>
               </div>
               <div class="panel-body">
               <div class="table-responsive">
                  
    <form action="LaporanSuratDalam.php" method="post" target="_blank">
    <table class="table table-condensed">
   
      <tr>
        <td><label for="">Tanggal Awal</label></td>
        <td><input name="tanggal_awal" type="date" class="form-control" id="tanggal_awal" placeholder="No Pelatihan" required/></td>
      </tr>
      <tr>
        <td><label for="">Tanggal Akhir</label></td>
        <td><input name="tanggal_akhir" type="date" class="form-control" id="tanggal_akhir" placeholder="Tanggal Pelatihan" required/></td>
      </tr>
     
      
      
      <tr>
        <td><input type="submit" value="Cetak"  class="btn btn-sm btn-primary" />&nbsp;<a href="beranda.php?hal=Depan" class="btn btn-sm btn-primary">Kembali</a></td>
        </tr>
    </table>
    </form>
                   </div>

                </div>
              </div>

            </div>
            <div class="col-lg-6">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title"><i class="fa fa-file"></i> Laporan Surat Luar Kota </h3>
              </div>
              <div class="panel-body">
                 <div class="table-responsive">
                  
    <form action="LaporanSuratLuar.php" method="post" target="_blank">
    <table class="table table-condensed">
   
      <tr>
        <td><label for="">Tanggal Awal</label></td>
        <td><input name="tanggal_awal" type="date" class="form-control" id="tanggal_awal" placeholder="No Pelatihan" required/></td>
      </tr>
      <tr>
        <td><label for="">Tanggal Akhir</label></td>
        <td><input name="tanggal_akhir" type="date" class="form-control" id="tanggal_akhir" placeholder="Tanggal Pelatihan" required/></td>
      </tr>
     
      
      
      <tr>
        <td><input type="submit" value="Cetak"  class="btn btn-sm btn-primary"/>&nbsp;<a href="beranda.php?hal=Depan" class="btn btn-sm btn-primary">Kembali</a></td>
        </tr>
    </table>
    </form>
                   </div>

          </div>

</div>
 <br><br><br><br>  <br><br><br><br>  <br><br><br><br>  <br><br><br><br>  <br><br><br><br>  <br><br><br><br>

        </div>



    



                </div>
              </div>

