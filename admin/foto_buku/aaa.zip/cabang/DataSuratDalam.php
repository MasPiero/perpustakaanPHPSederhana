 <div class="row">
      <div class="col-md-12">
        <h1 class="page-header">
            Data Surat Dalam Kota <small><?php  echo $_SESSION['nama_kpp']  ?></small>
        </h1>
       </div>
</div>

            <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                        Data Surat Dalam Kota
                        </div>
                        <div class="panel-body">
                           
              
                                    <?php
                                        $tampil=mysqli_query ($link,"SELECT * FROM tbsuratdalam LEFT JOIN tbkpp on tbsuratdalam.kode_kpp = tbkpp.kode_kpp LEFT JOIN tbbagian on tbsuratdalam.kode_bagian=tbbagian.kode_bagian LEFT JOIN tbstatus on tbsuratdalam.id_status=tbstatus.id_status where tbsuratdalam.kode_kpp = '$_SESSION[kode_kpp]' order by tbsuratdalam.id DESC");
                                          $no = 0;
                                    ?>
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr >
                                             <th>No</th>
                                             <th>No. Resi</th>
                                             <th>No. Surat</th>
                                           
                                              <th>Bagian</th>
                                              <th>Qty</th>
                                              <th>Tanggal Masuk</th>
                                               <th>Status</th> 
                                               <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while($data=mysqli_fetch_array($tampil))
                                             { $no++;
                                                ?>

                                            <tr>
                         
                          <td><?php echo $no; ?></td>
                         
                          <td><?php echo $data['no_resi']; ?></td>
                           <td><?php echo $data['no_surat']; ?></td>
                            
                             <td><?php echo $data['nama_bagian']; ?></td>
                              <td><?php echo $data['qty']; ?></td>
                              <td><?php echo tgl_indo( $data['tgl_masuk']); ?></td>
                              <td><?php 
                                if ($data['nama_status'] ==  "Terkirim")
                                  {echo "<span class='label label-primary'> $data[nama_status] </span>";}
                                 elseif ($data['nama_status'] ==  "Proses Kirim")
                                  {echo "<span class='label label-info'> $data[nama_status] </span>";}
                                  else
                                  { echo "<span class='label label-warning'> $data[nama_status] </span>";}
                               ?></span></td>

                             
                              
                             
                                                     
                          <td><a class="btn btn-info" href="beranda.php?hal=DetailSuratDalam&id=<?php echo $data['id']  ?>"> <i class="fa fa-arrow-left">Detail</i></a>
                          
                          </td>
                                               
                          
                          
                         </tr>
                                             <?php   
                                          }
                                          ?>
                                      
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                         <br><br><br><br>  <br><br><br><br>  <br><br><br><br>  <br><br><br><br>  <br><br><br><br>  <br><br><br><br>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>
                <!-- /. ROW  -->
            
                <!-- /. ROW  -->
            
                <!-- /. ROW  -->
            
                <!-- /. ROW  -->
        </div>
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
  
    
   

