<?php
if  ($_GET['hal']=='beranda')
	{include "beranda.php";}

	
else if  ($_GET['hal']=='DataSuratDalam')
	{include "DataSuratDalam.php";}
else if  ($_GET['hal']=='DataSuratLuar')
	{include "DataSuratLuar.php";}
else if  ($_GET['hal']=='Depan')
	{include "Depan.php";}
else if  ($_GET['hal']=='DetailSuratDalam')
	{include "DetailSuratDalam.php";}
else if  ($_GET['hal']=='DetailSuratLuar')
	{include "DetailSuratLuar.php";}


	
else if  ($_GET['hal']=='TambahJadwalPelatihan')
	{include "TambahJadwalPelatihan.php";}
else if  ($_GET['hal']=='PesertaUjian')
	{include "PesertaUjian.php";}
else if  ($_GET['hal']=='InputTest')
	{include "InputTest.php";}
else if  ($_GET['hal']=='Pengaturan')
	{include "Pengaturan.php";}
else if  ($_GET['hal']=='Laporan')
	{include "Laporan.php";}
?>
